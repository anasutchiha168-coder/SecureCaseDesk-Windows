// SECURECASEDESK_PHASE9_S2
import React, { createContext, useContext, useEffect, useState, useCallback, ReactNode } from 'react';
import * as Crypto from 'expo-crypto';
import * as SecureStore from 'expo-secure-store';
import { getDb } from '@/database/db';
import { setAuditActor, recordAuditEvent } from '@/services/audit.service';
import { purgeDecryptedCache } from '@/services/attachments.service';

export interface AuthUser {
  id: string;
  username: string;
  role: string;
  created_at: string;
  department_id?: string | null;
  is_active?: number;
  last_login?: number | null;
}

interface AuthContextValue {
  user: AuthUser | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  checkSession: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);
const SESSION_USER_ID_KEY = 'securecase_session_uid';

// محاولات الدخول الفاشلة لا تمسّ أي جدول، لذا لا يلتقطها أي trigger تلقائي؛
// تُسجَّل هنا صراحة. لا تُلقي أبداً: فشل التسجيل لا يجوز أن يمنع ظهور رسالة الخطأ للمستخدم.
async function recordFailedLogin(
  attemptedUsername: string,
  userId: string | null,
  reason: string
): Promise<void> {
  try {
    await recordAuditEvent({
      operationType: 'failed_login',
      entityType: 'session',
      entityId: userId,
      reason,
      actor: { id: userId, username: attemptedUsername || null },
    });
  } catch (e) {
    console.error('[AuthContext] تعذر تسجيل محاولة الدخول الفاشلة:', e);
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const checkSession = useCallback(async () => {
    try {
      const storedId = await SecureStore.getItemAsync(SESSION_USER_ID_KEY);
      if (!storedId) {
        setUser(null);
        return;
      }
      const db = await getDb();
      const row = await db.getFirstAsync<AuthUser>(
        'SELECT id, username, role, created_at, department_id, is_active, last_login FROM users WHERE id = ?',
        [storedId]
      );
      if (row && Number(row.is_active ?? 1) === 1) {
        setUser(row);
        await setAuditActor({ id: row.id, username: row.username });
      } else {
        await SecureStore.deleteItemAsync(SESSION_USER_ID_KEY);
        setUser(null);
        await setAuditActor(null);
      }
    } catch (err) {
      console.error('[AuthContext] checkSession error:', err);
      setUser(null);
      await setAuditActor(null).catch(() => {});
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    checkSession();
  }, [checkSession]);

  const login = useCallback(async (username: string, password: string) => {
    try {
      const db = await getDb();
      const passwordHash = await Crypto.digestStringAsync(
        Crypto.CryptoDigestAlgorithm.SHA256,
        password
      );
      const row = await db.getFirstAsync<AuthUser & { password_hash: string }>(
        'SELECT id, username, password_hash, role, created_at, department_id, is_active, last_login FROM users WHERE username = ?',
        [username.trim()]
      );

      if (!row) {
        await recordFailedLogin(username.trim(), null, 'اسم مستخدم غير موجود');
        return { success: false, error: 'اسم المستخدم غير موجود' };
      }

      if (Number(row.is_active ?? 1) !== 1) {
        await recordFailedLogin(row.username, row.id, 'الحساب معطّل');
        return { success: false, error: 'هذا الحساب معطّل، يرجى مراجعة مدير النظام' };
      }

      if (row.password_hash !== passwordHash) {
        await recordFailedLogin(row.username, row.id, 'كلمة مرور غير صحيحة');
        return { success: false, error: 'كلمة المرور غير صحيحة' };
      }

      const loginAt = Date.now();

      await db.runAsync(
        'UPDATE users SET last_login = ? WHERE id = ?',
        [loginAt, row.id]
      );

      const { password_hash, ...safeUser } = row;
      setUser({ ...safeUser, last_login: loginAt });
      await SecureStore.setItemAsync(SESSION_USER_ID_KEY, safeUser.id);

      // يُضبط سياق المنفّذ أولاً حتى تُنسب عملية "تسجيل الدخول" نفسها إليه،
      // ويُسجَّل الدخول كحدث تدقيق صريح (لا يلتقطه أي trigger لأنه ليس تعديل سجل).
      await setAuditActor({ id: safeUser.id, username: safeUser.username });
      await recordAuditEvent({
        operationType: 'login',
        entityType: 'session',
        entityId: safeUser.id,
        actor: { id: safeUser.id, username: safeUser.username },
      }).catch((e) => console.error('[AuthContext] تعذر تسجيل حدث الدخول في سجل التدقيق:', e));

      return { success: true };
    } catch (err) {
      console.error('[AuthContext] login error:', err);
      return { success: false, error: 'حدث خطأ أثناء تسجيل الدخول' };
    }
  }, []);

  const logout = useCallback(async () => {
    try {
      if (user) {
        await recordAuditEvent({
          operationType: 'logout',
          entityType: 'session',
          entityId: user.id,
          actor: { id: user.id, username: user.username },
        }).catch((e) => console.error('[AuthContext] تعذر تسجيل حدث الخروج في سجل التدقيق:', e));
      }
      await SecureStore.deleteItemAsync(SESSION_USER_ID_KEY);
    } catch (err) {
      console.error('[AuthContext] logout error:', err);
    } finally {
      purgeDecryptedCache(); // حذف أي نسخ مفكوكة من المرفقات ومفتاحها من الذاكرة
      setUser(null);
      await setAuditActor(null).catch(() => {});
    }
  }, [user]);

  return (
    <AuthContext.Provider value={{ user, isAuthenticated: !!user, isLoading, login, logout, checkSession }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>');
  return ctx;
}
