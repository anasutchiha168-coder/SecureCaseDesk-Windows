// SECURECASEDESK_PHASE9_S3
// خدمة التقارير للتطبيق: تبني المستند من قاعدة البيانات المشفرة (بعد فحص الصلاحيات)، ثم تنتج PDF (expo-print)
// أو DOCX (مولّد داخلي)، وتتحقق من سلامة الملف الناتج، وتسجّل العملية في سجل التدقيق (بدون محتوى التقرير).
// الملفات تُحفظ في مجلد الكاش المؤقت وتُنظَّف تلقائياً لأن التقارير تحوي بيانات حساسة غير مشفرة.

import * as Print from 'expo-print';
import * as Crypto from 'expo-crypto';
import { File, Directory, Paths } from 'expo-file-system';
import { sha256 } from '@noble/hashes/sha2.js';
import { bytesToHex } from '@noble/hashes/utils.js';
import { getDb } from '@/database/db';
import { can } from '@/security/permissions';
import { requirePerm, type Session } from '@/security/guard';
import { recordSystemEvent } from '@/modules/audit/audit-integration';
import type { DbLike } from '@/modules/attachments/attachments-repo';
import { buildReport } from '@/modules/reports/reports-data';
import { renderReportHtml } from '@/modules/reports/reports-html';
import { renderReportDocx } from '@/modules/reports/reports-docx';
import { safeFileName } from '@/modules/reports/reports-format';
import {
  REPORT_CATALOG, getReportDefinition,
  type ReportDefinition, type ReportFilters, type ReportFormat,
} from '@/modules/reports/reports-types';

export { ReportError, REPORT_ERROR_MESSAGES } from '@/modules/reports/reports-types';
export type { ReportFilters, ReportFormat, ReportDefinition } from '@/modules/reports/reports-types';

export interface GeneratedReport {
  fileName: string;
  uri: string;
  format: ReportFormat;
  sizeBytes: number;
  sha256: string;
  rowCount: number;
  title: string;
  documentNumber: string;
  createdAt: number;
}

const KEEP_MS = 24 * 60 * 60 * 1000; // تنظيف تلقائي للملفات الأقدم من 24 ساعة

function reportsDir(): Directory {
  const d = new Directory(Paths.cache, 'reports');
  if (!d.exists) d.create({ intermediates: true, idempotent: true });
  return d;
}

// عرض فقط: الإنفاذ الحقيقي داخل buildReport.
export function listAvailableReports(session: Session | null | undefined): ReportDefinition[] {
  if (!session) return [];
  return REPORT_CATALOG.filter((r) => can(session.role, r.permission));
}

export function cleanupOldReports(maxAgeMs: number = KEEP_MS): number {
  let n = 0;
  try {
    const now = Date.now();
    for (const item of reportsDir().list()) {
      if (item instanceof File && now - (item.modificationTime ?? 0) > maxAgeMs) { item.delete(); n++; }
    }
  } catch (e) { console.error('[Reports] تعذر التنظيف:', e); }
  return n;
}

export function deleteGeneratedReport(uri: string): void {
  const f = new File(uri);
  // لا نحذف إلا داخل مجلد التقارير.
  if (!uri.includes('/reports/')) throw new Error('INVALID_REPORT_PATH');
  if (f.exists) f.delete();
}

function verifyOutput(bytes: Uint8Array, format: ReportFormat): void {
  const head = (s: string) => s.split('').every((c, i) => bytes[i] === c.charCodeAt(0));
  const ok = bytes.length > 500 && (format === 'pdf' ? head('%PDF-') : head('PK'));
  if (!ok) throw new Error('REPORT_OUTPUT_INVALID');
}

export async function generateReport(
  session: Session | null | undefined,
  kind: string,
  format: ReportFormat,
  filters: ReportFilters = {}
): Promise<GeneratedReport> {
  const def = getReportDefinition(kind);
  if (def) requirePerm(session, def.permission); // قبل أي لمس للقاعدة أو الملفات
  const database = (await getDb()) as unknown as DbLike;
  const doc = await buildReport({ db: database, now: () => Date.now() }, session, kind, filters);

  cleanupOldReports();
  const dir = reportsDir();
  const base = safeFileName(doc.title, doc.createdAt) + '_' + Crypto.randomUUID().slice(0, 6);
  const fileName = base + '.' + format;
  const target = new File(dir, fileName);
  if (target.exists) target.delete();

  if (format === 'docx') {
    target.create();
    target.write(renderReportDocx(doc));
  } else {
    // A4 بالنقاط: 595 × 842. الطباعة الأصلية في أندرويد تتولى تشكيل الحروف العربية واتجاه النص.
    const { uri } = await Print.printToFileAsync({ html: renderReportHtml(doc), width: 595, height: 842 });
    new File(uri).move(target);
  }

  const bytes = await target.bytes();
  try { verifyOutput(bytes, format); } catch (e) { if (target.exists) target.delete(); throw e; }
  const digest = bytesToHex(sha256(bytes));

  await recordSystemEvent(session, def!.permission, {
    operationType: 'report_generate',
    entityType: 'report',
    entityId: doc.documentNumber,
    newValues: { kind: doc.kind, format, rows: doc.rowCount, size: bytes.length, sha256: digest },
    reason: 'إنشاء تقرير ' + doc.title,
  });

  return {
    fileName, uri: target.uri, format, sizeBytes: bytes.length, sha256: digest, rowCount: doc.rowCount,
    title: doc.title, documentNumber: doc.documentNumber, createdAt: doc.createdAt,
  };
}
