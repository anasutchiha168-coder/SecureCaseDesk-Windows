// SECURECASEDESK_PHASE9_S4
// مشاركة وطباعة التقارير على Android. قبل كل عملية: إعادة فحص الصلاحيات من قاعدة البيانات،
// والتحقق من سلامة الملف (بنية + SHA-256)، ثم تسجيل الحدث في سجل التدقيق (إلزامي: فشل التسجيل يوقف التصدير).

import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { File } from 'expo-file-system';
import { sha256 } from '@noble/hashes/sha2.js';
import { bytesToHex } from '@noble/hashes/utils.js';
import { getDb } from '@/database/db';
import type { Session } from '@/security/guard';
import { recordSystemEvent } from '@/modules/audit/audit-integration';
import type { DbLike } from '@/modules/attachments/attachments-repo';
import { buildReport } from '@/modules/reports/reports-data';
import { renderReportHtml } from '@/modules/reports/reports-html';
import type { ReportFilters } from '@/modules/reports/reports-types';
import {
  assertReportPath, authorizeReportAction, exportAuditEvent, verifyReportFile,
  ExportError, EXPORT_ERROR_MESSAGES, REPORT_MIME, REPORT_UTI,
} from '@/modules/reports/reports-export-logic';
import type { GeneratedReport } from '@/services/reports.service';

export { ExportError, EXPORT_ERROR_MESSAGES };

const hex = (b: Uint8Array) => bytesToHex(sha256(b));

// يشارك ملف PDF أو DOCX المُنشأ سابقاً (واتساب، البريد، حفظ في «الملفات»...).
export async function shareReportFile(session: Session | null | undefined, report: GeneratedReport, kind: string): Promise<void> {
  const db = (await getDb()) as unknown as DbLike;
  const { def } = await authorizeReportAction(db, session, kind);
  const format = assertReportPath(report.uri);
  if (format !== report.format) throw new ExportError('NOT_REPORT_FILE');

  const file = new File(report.uri);
  if (!file.exists) throw new ExportError('FILE_MISSING');
  const bytes = await file.bytes();
  verifyReportFile(bytes, format, report.sha256, hex);

  if (!(await Sharing.isAvailableAsync())) throw new ExportError('SHARE_UNAVAILABLE');

  await recordSystemEvent(session, def.permission,
    exportAuditEvent('share', def, { format, documentNumber: report.documentNumber, sizeBytes: bytes.length, sha256: report.sha256 }), true);

  await Sharing.shareAsync(report.uri, { mimeType: REPORT_MIME[format], UTI: REPORT_UTI[format], dialogTitle: 'مشاركة التقرير' });
}

// يطبع التقرير. أندرويد لا يطبع ملفاً جاهزاً من مساره، فيُعاد بناء التقرير من البيانات الحالية
// (بنفس فحص الصلاحيات) ثم يُرسل لخدمة الطباعة الأصلية. قد تختلف الأرقام عن ملف أُنشئ قبل ساعات.
export async function printReport(session: Session | null | undefined, kind: string, filters: ReportFilters = {}): Promise<void> {
  const db = (await getDb()) as unknown as DbLike;
  const { def } = await authorizeReportAction(db, session, kind);
  const doc = await buildReport({ db, now: () => Date.now() }, session, kind, filters);

  await recordSystemEvent(session, def.permission,
    exportAuditEvent('print', def, { format: 'html', documentNumber: doc.documentNumber }), true);

  await Print.printAsync({ html: renderReportHtml(doc) });
}
