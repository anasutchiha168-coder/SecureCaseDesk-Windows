// SECURECASEDESK_PHASE9_S1
// تخزين الملفات المشفرة على الجهاز عبر expo-file-system (واجهة File/Directory الحديثة).
// المسار: <document>/attachments/<uuid>.enc  — أسماء عشوائية لا تكشف اسم الملف الأصلي.
// ⚠️ أسماء دوال File/Directory تحتاج تحقق tsc على الجهاز الفعلي (انظر ملاحظات التسليم).

import { Directory, File, Paths } from 'expo-file-system';
import type { BlobStorage } from './attachments-repo';

const SAFE_NAME = /^[0-9a-f-]{36}\.enc$/;

function dir(): Directory {
  const d = new Directory(Paths.document, 'attachments');
  if (!d.exists) d.create({ intermediates: true, idempotent: true });
  return d;
}

function assertSafe(name: string): void {
  if (!SAFE_NAME.test(name)) throw new Error('INVALID_STORAGE_NAME');
}

export const expoBlobStorage: BlobStorage = {
  async write(name, bytes) {
    assertSafe(name);
    const d = dir();
    const tmp = new File(d, name + '.tmp');
    if (tmp.exists) tmp.delete();
    tmp.create();
    tmp.write(bytes);
    if (tmp.size !== bytes.length) { tmp.delete(); throw new Error('SHORT_WRITE'); }
    const finalFile = new File(d, name);
    if (finalFile.exists) finalFile.delete();
    tmp.move(finalFile); // إعادة تسمية ذرّية داخل نفس المجلد
  },
  async read(name) {
    assertSafe(name);
    const f = new File(dir(), name);
    if (!f.exists) throw new Error('FILE_MISSING');
    return f.bytes();
  },
  async delete(name) {
    assertSafe(name);
    const f = new File(dir(), name);
    if (f.exists) f.delete();
  },
  async exists(name) {
    assertSafe(name);
    return new File(dir(), name).exists;
  },
  async list() {
    const names: string[] = [];
    for (const item of dir().list()) {
      if (item instanceof File) {
        if (item.name.endsWith('.tmp')) { item.delete(); continue; } // بقايا كتابة منقطعة
        names.push(item.name);
      }
    }
    return names;
  },
};
