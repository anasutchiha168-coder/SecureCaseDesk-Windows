// SECURECASEDESK_PHASE9_S2
import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Pressable,
  Modal,
  TextInput,
  Alert,
  ActivityIndicator,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from 'expo-router'; // SECURECASEDESK_PHASE11_S5
import { consumeMemoPrefill } from '@/modules/ai/ai-memo-handoff-runtime';
import type { MemoPrefill } from '@/modules/ai/ai-memo-handoff';
import { Plus, X, FileText, ChevronDown, Check } from 'lucide-react-native';
import { Colors } from '@/constants/theme';
import { useAuth } from '@/context/AuthContext';
import { ForbiddenError, type Session } from '@/security/guard';
import { listMemos, listMemoTypes, insertMemo, changeMemoStatus, DuplicateMemoError, type MemoItem } from '@/services/memos.service';
import { listCaseOptions } from '@/services/cases.service';
import AttachmentsPanel from '@/components/attachments/AttachmentsPanel';


interface MemoTypeItem {
  id: string;
  name: string;
}

interface CaseOption {
  id: string;
  case_number: string;
  title: string;
}

const ALL_STATUSES = ['مسودة', 'مرسلة', 'مؤرشفة'];

function formatDate(ts: number): string {
  const d = new Date(ts);
  return d.toLocaleDateString('ar-YE', { year: 'numeric', month: 'long', day: 'numeric' });
}

export default function MemosScreen() {
  const { user } = useAuth();
  const session = React.useMemo<Session | null>(
    () => (user ? { userId: user.id, role: user.role } : null),
    [user?.id, user?.role]
  );
  const deniedAlerted = React.useRef(false);
  const [memos, setMemos] = useState<MemoItem[]>([]);
  const [memoTypes, setMemoTypes] = useState<MemoTypeItem[]>([]);
  const [caseOptions, setCaseOptions] = useState<CaseOption[]>([]);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [statusUpdating, setStatusUpdating] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [typePickerVisible, setTypePickerVisible] = useState(false);
  const [casePickerVisible, setCasePickerVisible] = useState(false);

  // معاينة المذكرة
  const [previewVisible, setPreviewVisible] = useState(false);
  const [previewMemo, setPreviewMemo] = useState<MemoItem | null>(null);

  // حقول النموذج
  const [memoNumber, setMemoNumber] = useState('');
  const [recipientOrg, setRecipientOrg] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [selectedType, setSelectedType] = useState<MemoTypeItem | null>(null);
  const [selectedCase, setSelectedCase] = useState<CaseOption | null>(null);

  const today = new Date();
  const [dayStr, setDayStr] = useState(String(today.getDate()));
  const [monthStr, setMonthStr] = useState(String(today.getMonth() + 1));
  const [yearStr, setYearStr] = useState(String(today.getFullYear()));
  const [pendingPrefill, setPendingPrefill] = useState<MemoPrefill | null>(null); // SECURECASEDESK_PHASE11_S5
  const [prefillNote, setPrefillNote] = useState<string | null>(null);
  const placeholderAck = React.useRef(false);

  const typeMap = React.useMemo(() => {
    const map: Record<string, string> = {};
    memoTypes.forEach((t) => { map[t.id] = t.name; });
    return map;
  }, [memoTypes]);

  const caseMap = React.useMemo(() => {
    const map: Record<string, string> = {};
    caseOptions.forEach((c) => { map[c.id] = c.case_number; });
    return map;
  }, [caseOptions]);

  const loadMemoTypes = useCallback(async () => {
    if (!session) return;
    try { setMemoTypes(await listMemoTypes(session)); }
    catch (error) {
      setMemoTypes([]);
      if (!(error instanceof ForbiddenError)) console.error('[memos] loadMemoTypes error:', error);
    }
  }, [session]);

  const loadCaseOptions = useCallback(async () => {
    if (!session) return;
    try { setCaseOptions(await listCaseOptions(session)); }
    catch (error) {
      setCaseOptions([]); // بلا صلاحية عرض القضايا: لا ربط بقضية، ولا تنبيه
      if (!(error instanceof ForbiddenError)) console.error('[memos] loadCaseOptions error:', error);
    }
  }, [session]);

  const loadMemos = useCallback(async () => {
    if (!session) return; // الجلسة لم تُحمَّل بعد: لا استعلام ولا تنبيه
    try { setMemos(await listMemos(session)); }
    catch (error) {
      setMemos([]);
      if (error instanceof ForbiddenError) {
        if (!deniedAlerted.current) {
          deniedAlerted.current = true;
          Alert.alert('تنبيه', 'ليست لديك صلاحية');
        }
      } else {
        console.error('[memos] loadMemos error:', error);
        Alert.alert('خطأ', 'حدث خطأ أثناء تحميل المذكرات');
      }
    }
    finally { setLoading(false); }
  }, [session]);

  useEffect(() => {
    loadMemoTypes();
    loadCaseOptions();
    loadMemos();
  }, [loadMemoTypes, loadCaseOptions, loadMemos]);

  const resetForm = () => {
    setMemoNumber('');
    setRecipientOrg('');
    setSubject('');
    setBody('');
    setSelectedType(null);
    setSelectedCase(null);
    setPrefillNote(null);
    const now = new Date();
    setDayStr(String(now.getDate()));
    setMonthStr(String(now.getMonth() + 1));
    setYearStr(String(now.getFullYear()));
  };

  // SECURECASEDESK_PHASE11_S5: تعبئة النموذج من مسودة المساعد الذكي (دون حفظ). تُستهلك مرة واحدة عند فتح الشاشة.
  useFocusEffect(useCallback(() => {
    let alive = true;
    if (session) {
      void consumeMemoPrefill(session).then((p) => { if (alive && p) setPendingPrefill(p); }).catch(() => undefined);
    }
    return () => { alive = false; };
  }, [session]));

  useEffect(() => {
    if (!pendingPrefill) return;
    if (memoTypes.length === 0 && loading) return; // انتظر تحميل أنواع المذكرات
    const p = pendingPrefill;
    setPendingPrefill(null);
    resetForm();
    setRecipientOrg(p.recipient);
    setSubject(p.subject);
    setBody(p.body);
    setSelectedType(memoTypes.find((t) => t.name.trim() === p.memoTypeName) ?? null);
    setSelectedCase(p.caseId ? caseOptions.find((c) => c.id === p.caseId) ?? null : null);
    setPrefillNote(
      'معبّأ من مسودة المساعد الذكي ولم يُحفظ بعد. اكتب رقم المذكرة، وتحقق من النوع والتاريخ وكل الحقول، وأكمل الفراغات' +
      (p.placeholders > 0 ? ' (' + p.placeholders + ' فراغ بصيغة [......] في النص)' : '') + ' قبل الحفظ.'
    );
    setModalVisible(true);
  }, [pendingPrefill, memoTypes, caseOptions, loading]);

  const buildMemoDateTimestamp = (): number | null => {
    const day = parseInt(dayStr, 10);
    const month = parseInt(monthStr, 10);
    const year = parseInt(yearStr, 10);
    if (
      !Number.isInteger(day) || !Number.isInteger(month) || !Number.isInteger(year) ||
      day < 1 || day > 31 || month < 1 || month > 12 || year < 2000 || year > 2100
    ) {
      return null;
    }
    const date = new Date(year, month - 1, day);
    if (date.getMonth() !== month - 1) return null;
    return date.getTime();
  };

  const handleSaveMemo = async () => {
    const trimmedNumber = memoNumber.trim(); const trimmedRecipient = recipientOrg.trim(); const trimmedSubject = subject.trim();
    if (!trimmedNumber || !trimmedRecipient || !trimmedSubject || !selectedType) { Alert.alert('تنبيه', 'يرجى إدخال رقم المذكرة، الجهة المرسل إليها، الموضوع، واختيار نوع المذكرة'); return; }
    const memoDateTs = buildMemoDateTimestamp();
    if (memoDateTs === null) { Alert.alert('تنبيه', 'تاريخ المذكرة غير صحيح'); return; }
    // SECURECASEDESK_PHASE11_S5: فراغات [......] المتبقية تحتاج إقراراً صريحاً قبل الحفظ.
    const leftover = (body.match(/\[(?:\.{2,}|\u2026+)\]/g) ?? []).length;
    if (leftover > 0 && !placeholderAck.current) {
      Alert.alert('فراغات لم تُملأ', 'يحتوي نص المذكرة على ' + leftover + ' فراغ بصيغة [......]. أكملها قبل الحفظ، أو احفظ كما هي.', [
        { text: 'رجوع للتعديل', style: 'cancel' },
        { text: 'حفظ كما هي', onPress: () => { placeholderAck.current = true; void handleSaveMemo(); } },
      ]);
      return;
    }
    placeholderAck.current = false;
    setSaving(true);
    try {
      await insertMemo(session, {
        memoNumber: trimmedNumber,
        memoTypeId: selectedType.id,
        memoDate: memoDateTs,
        recipientOrganization: trimmedRecipient,
        subject: trimmedSubject,
        body,
        linkedCaseId: selectedCase?.id ?? null,
      });
      setModalVisible(false); resetForm(); await loadMemos();
    } catch (error) {
      if (error instanceof ForbiddenError) {
        Alert.alert('تنبيه', 'ليست لديك صلاحية');
      } else if (error instanceof DuplicateMemoError) {
        Alert.alert('خطأ', `رقم المذكرة "${trimmedNumber}" مستخدم مسبقاً`);
      } else {
        console.error('[memos] save error:', error);
        Alert.alert('خطأ', 'فشل حفظ المذكرة');
      }
    }
    finally { setSaving(false); }
  };

  const openPreview = (memo: MemoItem) => {
    setPreviewMemo(memo);
    setPreviewVisible(true);
  };

  const handleChangeStatus = async (newStatus: string) => {
    if (!previewMemo || newStatus === previewMemo.status) return;
    try {
      const updatedAt = await changeMemoStatus(session, previewMemo.id, newStatus);
      const updatedMemo: MemoItem = { ...previewMemo, status: newStatus, updated_at: updatedAt };
      setPreviewMemo(updatedMemo); setMemos((prev) => prev.map((m) => (m.id === updatedMemo.id ? updatedMemo : m)));
    } catch (error) {
      if (error instanceof ForbiddenError) {
        Alert.alert('تنبيه', 'ليست لديك صلاحية');
      } else {
        console.error('[memos] status error:', error);
        Alert.alert('فشل تحديث الحالة', 'تعذر تحديث حالة المذكرة');
      }
    }
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>المذكرات الرسمية</Text>
        <Pressable
          style={styles.addBtn}
          onPress={() => setModalVisible(true)}
          accessibilityLabel="إضافة مذكرة جديدة"
        >
          <Plus color="#fff" size={24} />
        </Pressable>
      </View>

      {loading ? (
        <ActivityIndicator size="large" color={Colors.primary} style={{ marginTop: 50 }} />
      ) : (
        <FlatList
          data={memos}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ padding: 16, flexGrow: 1 }}
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <FileText color={Colors.textMuted} size={48} />
              <Text style={styles.emptyText}>لا توجد مذكرات مسجلة حالياً</Text>
            </View>
          }
          renderItem={({ item }) => (
            <Pressable style={styles.memoCard} onPress={() => openPreview(item)}>
              <View style={styles.memoHeader}>
                <Text style={styles.memoNumber}>{item.memo_number}</Text>
                <View style={styles.statusBadge}>
                  <Text style={styles.statusText}>{item.status}</Text>
                </View>
              </View>
              <Text style={styles.memoSubject}>{item.subject}</Text>
              <Text style={styles.memoType}>{typeMap[item.memo_type_id] ?? '—'}</Text>
              <View style={styles.memoMetaRow}>
                <Text style={styles.memoMeta}>إلى: {item.recipient_organization}</Text>
                <Text style={styles.memoMeta}>{formatDate(item.memo_date)}</Text>
              </View>
              {item.linked_case_id && (
                <Text style={styles.memoLinkedCase}>
                  مرتبطة بالقضية: {caseMap[item.linked_case_id] ?? '—'}
                </Text>
              )}
            </Pressable>
          )}
        />
      )}

      {/* نافذة إضافة مذكرة */}
      <Modal visible={modalVisible} animationType="slide" transparent>
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          style={styles.modalOverlay}
        >
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>تسجيل مذكرة جديدة</Text>
              <Pressable
                onPress={() => {
                  setModalVisible(false);
                  resetForm();
                }}
                accessibilityLabel="إغلاق"
              >
                <X color={Colors.textPrimary} size={24} />
              </Pressable>
            </View>

            {prefillNote && (
              <Text style={{ color: Colors.warning, fontFamily: 'Cairo_600SemiBold', fontSize: 13, textAlign: 'right', marginBottom: 8 }}>{prefillNote}</Text>
            )}
            <ScrollView showsVerticalScrollIndicator={false}>
              <TextInput
                style={styles.input}
                placeholder="رقم المذكرة *"
                placeholderTextColor={Colors.textMuted}
                value={memoNumber}
                onChangeText={setMemoNumber}
                editable={!saving}
              />

              <Pressable
                style={styles.selector}
                onPress={() => setTypePickerVisible(true)}
                disabled={saving}
              >
                <Text style={[styles.selectorText, !selectedType && { color: Colors.textMuted }]}>
                  {selectedType ? selectedType.name : 'اختر نوع المذكرة *'}
                </Text>
                <ChevronDown color={Colors.textMuted} size={18} />
              </Pressable>

              <Text style={styles.fieldLabel}>تاريخ المذكرة *</Text>
              <View style={styles.dateRow}>
                <TextInput
                  style={styles.dateInput}
                  placeholder="يوم"
                  placeholderTextColor={Colors.textMuted}
                  keyboardType="number-pad"
                  value={dayStr}
                  onChangeText={setDayStr}
                  maxLength={2}
                  editable={!saving}
                />
                <TextInput
                  style={styles.dateInput}
                  placeholder="شهر"
                  placeholderTextColor={Colors.textMuted}
                  keyboardType="number-pad"
                  value={monthStr}
                  onChangeText={setMonthStr}
                  maxLength={2}
                  editable={!saving}
                />
                <TextInput
                  style={[styles.dateInput, { flex: 1.4 }]}
                  placeholder="سنة"
                  placeholderTextColor={Colors.textMuted}
                  keyboardType="number-pad"
                  value={yearStr}
                  onChangeText={setYearStr}
                  maxLength={4}
                  editable={!saving}
                />
              </View>

              <TextInput
                style={styles.input}
                placeholder="الجهة المرسل إليها *"
                placeholderTextColor={Colors.textMuted}
                value={recipientOrg}
                onChangeText={setRecipientOrg}
                editable={!saving}
              />
              <TextInput
                style={styles.input}
                placeholder="الموضوع *"
                placeholderTextColor={Colors.textMuted}
                value={subject}
                onChangeText={setSubject}
                editable={!saving}
              />
              <TextInput
                style={[styles.input, { height: 120, textAlignVertical: 'top' }]}
                placeholder="نص المذكرة"
                placeholderTextColor={Colors.textMuted}
                multiline
                value={body}
                onChangeText={setBody}
                editable={!saving}
              />

              <Pressable
                style={styles.selector}
                onPress={() => setCasePickerVisible(true)}
                disabled={saving}
              >
                <Text style={[styles.selectorText, !selectedCase && { color: Colors.textMuted }]}>
                  {selectedCase ? `${selectedCase.case_number} - ${selectedCase.title}` : 'ربط بقضية (اختياري)'}
                </Text>
                <ChevronDown color={Colors.textMuted} size={18} />
              </Pressable>

              <Pressable
                style={[styles.saveBtn, saving && { opacity: 0.6 }]}
                onPress={handleSaveMemo}
                disabled={saving}
              >
                {saving ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.saveBtnText}>حفظ المذكرة</Text>
                )}
              </Pressable>
            </ScrollView>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* نافذة اختيار نوع المذكرة */}
      <Modal visible={typePickerVisible} animationType="fade" transparent>
        <Pressable style={styles.pickerOverlay} onPress={() => setTypePickerVisible(false)}>
          <View style={styles.pickerContent}>
            <Text style={styles.pickerTitle}>اختر نوع المذكرة</Text>
            <ScrollView style={{ maxHeight: 360 }}>
              {memoTypes.map((t) => (
                <Pressable
                  key={t.id}
                  style={styles.pickerOption}
                  onPress={() => {
                    setSelectedType(t);
                    setTypePickerVisible(false);
                  }}
                >
                  <Text style={styles.pickerOptionText}>{t.name}</Text>
                  {selectedType?.id === t.id && <Check color={Colors.primary} size={18} />}
                </Pressable>
              ))}
            </ScrollView>
          </View>
        </Pressable>
      </Modal>

      {/* نافذة اختيار القضية */}
      <Modal visible={casePickerVisible} animationType="fade" transparent>
        <Pressable style={styles.pickerOverlay} onPress={() => setCasePickerVisible(false)}>
          <View style={styles.pickerContent}>
            <Text style={styles.pickerTitle}>اختر القضية المرتبطة</Text>
            <ScrollView style={{ maxHeight: 360 }}>
              <Pressable
                style={styles.pickerOption}
                onPress={() => {
                  setSelectedCase(null);
                  setCasePickerVisible(false);
                }}
              >
                <Text style={styles.pickerOptionText}>بدون ربط بقضية</Text>
                {!selectedCase && <Check color={Colors.primary} size={18} />}
              </Pressable>
              {caseOptions.map((c) => (
                <Pressable
                  key={c.id}
                  style={styles.pickerOption}
                  onPress={() => {
                    setSelectedCase(c);
                    setCasePickerVisible(false);
                  }}
                >
                  <Text style={styles.pickerOptionText}>{c.case_number} - {c.title}</Text>
                  {selectedCase?.id === c.id && <Check color={Colors.primary} size={18} />}
                </Pressable>
              ))}
              {caseOptions.length === 0 && (
                <Text style={[styles.pickerOptionText, { padding: 12, color: Colors.textMuted }]}>
                  لا توجد قضايا مسجلة بعد
                </Text>
              )}
            </ScrollView>
          </View>
        </Pressable>
      </Modal>

      {/* نافذة معاينة المذكرة — بتصميم خطاب رسمي */}
      <Modal visible={previewVisible} animationType="slide" transparent>
        <View style={styles.previewOverlay}>
          <View style={styles.previewWrapper}>
            <View style={styles.previewTopBar}>
              <Text style={styles.previewTopBarTitle}>معاينة المذكرة</Text>
              <Pressable onPress={() => setPreviewVisible(false)} accessibilityLabel="إغلاق المعاينة">
                <X color={Colors.textPrimary} size={24} />
              </Pressable>
            </View>

            {previewMemo && (
              <ScrollView style={styles.letterScroll} showsVerticalScrollIndicator={false}>
                {/* ورقة الخطاب الرسمي */}
                <View style={styles.letterPaper}>
                  <View style={styles.letterHeader}>
                    <Text style={styles.letterMinistry}>وزارة الداخلية</Text>
                    <Text style={styles.letterDept}>إدارة المباحث الجنائية</Text>
                    <Text style={styles.letterGov}>م / حجة</Text>
                  </View>

                  <View style={styles.letterDivider} />

                  <View style={styles.letterMetaRow}>
                    <Text style={styles.letterMetaText}>
                      رقم المذكرة: {previewMemo.memo_number}
                    </Text>
                    <Text style={styles.letterMetaText}>
                      التاريخ: {formatDate(previewMemo.memo_date)}
                    </Text>
                  </View>
                  <Text style={styles.letterMetaText}>
                    النوع: {typeMap[previewMemo.memo_type_id] ?? '—'}
                  </Text>
                  <Text style={styles.letterMetaText}>
                    إلى: {previewMemo.recipient_organization}
                  </Text>
                  {previewMemo.linked_case_id && (
                    <Text style={styles.letterMetaText}>
                      مرتبطة بالقضية رقم: {caseMap[previewMemo.linked_case_id] ?? '—'}
                    </Text>
                  )}

                  <Text style={styles.letterSubjectLabel}>الموضوع:</Text>
                  <Text style={styles.letterSubject}>{previewMemo.subject}</Text>

                  <Text style={styles.letterBody}>
                    {previewMemo.body || 'لا يوجد نص مُدخل لهذه المذكرة.'}
                  </Text>

                  <View style={styles.signatureArea}>
                    <View style={styles.signatureBlock}>
                      <Text style={styles.signatureLabel}>التوقيع</Text>
                      <View style={styles.signatureLine} />
                    </View>
                    <View style={styles.signatureBlock}>
                      <Text style={styles.signatureLabel}>الختم الرسمي</Text>
                      <View style={styles.signatureLine} />
                    </View>
                  </View>
                </View>

                <View style={{ marginTop: 16 }}>
                  <AttachmentsPanel entityType="memo" entityId={previewMemo.id} />
                </View>

                {/* أزرار تغيير الحالة */}
                <View style={styles.statusActionsBox}>
                  <Text style={styles.statusActionsTitle}>
                    الحالة الحالية: {previewMemo.status}
                  </Text>
                  <View style={styles.statusButtonsRow}>
                    {ALL_STATUSES.map((s) => {
                      const isCurrent = s === previewMemo.status;
                      return (
                        <Pressable
                          key={s}
                          style={[
                            styles.statusButton,
                            isCurrent && styles.statusButtonActive,
                          ]}
                          onPress={() => handleChangeStatus(s)}
                          disabled={isCurrent || statusUpdating}
                        >
                          {statusUpdating && !isCurrent ? (
                            <ActivityIndicator size="small" color={Colors.primary} />
                          ) : (
                            <Text
                              style={[
                                styles.statusButtonText,
                                isCurrent && styles.statusButtonTextActive,
                              ]}
                            >
                              {s}
                            </Text>
                          )}
                        </Pressable>
                      );
                    })}
                  </View>
                </View>
              </ScrollView>
            )}
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  headerTitle: { color: Colors.textPrimary, fontSize: 20, fontFamily: 'Cairo_700Bold' },
  addBtn: {
    backgroundColor: Colors.primary,
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyState: { alignItems: 'center', marginTop: 100 },
  emptyText: { color: Colors.textMuted, fontFamily: 'Cairo_400Regular', marginTop: 10 },
  memoCard: {
    backgroundColor: Colors.card,
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  memoHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  memoNumber: { color: Colors.primary, fontFamily: 'Cairo_700Bold', fontSize: 16 },
  statusBadge: {
    backgroundColor: 'rgba(37, 99, 235, 0.2)',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 8,
  },
  statusText: { color: Colors.primary, fontFamily: 'Cairo_600SemiBold', fontSize: 12 },
  memoSubject: { color: Colors.textPrimary, fontFamily: 'Cairo_600SemiBold', fontSize: 16 },
  memoType: {
    color: Colors.textMuted,
    fontFamily: 'Cairo_400Regular',
    fontSize: 12,
    marginTop: 2,
    textAlign: 'right',
  },
  memoMetaRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 6,
  },
  memoMeta: {
    color: Colors.textMuted,
    fontFamily: 'Cairo_400Regular',
    fontSize: 12,
  },
  memoLinkedCase: {
    color: Colors.primary,
    fontFamily: 'Cairo_400Regular',
    fontSize: 12,
    marginTop: 6,
    textAlign: 'right',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: Colors.card,
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: Colors.border,
    maxHeight: '88%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: { color: Colors.textPrimary, fontSize: 18, fontFamily: 'Cairo_700Bold' },
  input: {
    backgroundColor: Colors.background,
    color: Colors.textPrimary,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
    fontFamily: 'Cairo_400Regular',
    textAlign: 'right',
  },
  selector: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: Colors.background,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
  },
  selectorText: {
    color: Colors.textPrimary,
    fontFamily: 'Cairo_400Regular',
    fontSize: 14,
  },
  fieldLabel: {
    color: Colors.textMuted,
    fontFamily: 'Cairo_400Regular',
    fontSize: 13,
    marginBottom: 8,
    textAlign: 'right',
  },
  dateRow: {
    flexDirection: 'row-reverse',
    gap: 10,
    marginBottom: 16,
  },
  dateInput: {
    flex: 1,
    backgroundColor: Colors.background,
    color: Colors.textPrimary,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    padding: 12,
    fontFamily: 'Cairo_400Regular',
    textAlign: 'center',
  },
  saveBtn: {
    backgroundColor: Colors.primary,
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 8,
  },
  saveBtnText: { color: '#fff', fontFamily: 'Cairo_700Bold', fontSize: 16 },
  pickerOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'center',
    padding: 30,
  },
  pickerContent: {
    backgroundColor: Colors.card,
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  pickerTitle: {
    color: Colors.textPrimary,
    fontFamily: 'Cairo_700Bold',
    fontSize: 16,
    textAlign: 'right',
    marginBottom: 12,
  },
  pickerOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  pickerOptionText: {
    color: Colors.textPrimary,
    fontFamily: 'Cairo_400Regular',
    fontSize: 14,
    flexShrink: 1,
    textAlign: 'right',
  },

  /* ===== معاينة الخطاب الرسمي ===== */
  previewOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.85)',
  },
  previewWrapper: {
    flex: 1,
    paddingTop: 50,
  },
  previewTopBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 12,
  },
  previewTopBarTitle: {
    color: Colors.textPrimary,
    fontFamily: 'Cairo_700Bold',
    fontSize: 16,
  },
  letterScroll: {
    flex: 1,
    paddingHorizontal: 16,
  },
  letterPaper: {
    backgroundColor: '#F4F3EF',
    borderRadius: 10,
    padding: 20,
    marginBottom: 16,
  },
  letterHeader: {
    alignItems: 'center',
    marginBottom: 12,
  },
  letterMinistry: {
    color: '#1A1A1A',
    fontFamily: 'Cairo_700Bold',
    fontSize: 18,
  },
  letterDept: {
    color: '#1A1A1A',
    fontFamily: 'Cairo_600SemiBold',
    fontSize: 15,
    marginTop: 2,
  },
  letterGov: {
    color: '#3A3A3A',
    fontFamily: 'Cairo_400Regular',
    fontSize: 13,
    marginTop: 2,
  },
  letterDivider: {
    height: 1,
    backgroundColor: '#C9C7BE',
    marginVertical: 12,
  },
  letterMetaRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  letterMetaText: {
    color: '#2A2A2A',
    fontFamily: 'Cairo_400Regular',
    fontSize: 13,
    marginBottom: 4,
    textAlign: 'right',
  },
  letterSubjectLabel: {
    color: '#1A1A1A',
    fontFamily: 'Cairo_700Bold',
    fontSize: 14,
    marginTop: 14,
    textAlign: 'right',
  },
  letterSubject: {
    color: '#1A1A1A',
    fontFamily: 'Cairo_600SemiBold',
    fontSize: 15,
    marginTop: 4,
    textAlign: 'right',
  },
  letterBody: {
    color: '#2A2A2A',
    fontFamily: 'Cairo_400Regular',
    fontSize: 14,
    marginTop: 16,
    lineHeight: 24,
    textAlign: 'right',
  },
  signatureArea: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 40,
  },
  signatureBlock: {
    alignItems: 'center',
    width: '45%',
  },
  signatureLabel: {
    color: '#3A3A3A',
    fontFamily: 'Cairo_400Regular',
    fontSize: 12,
    marginBottom: 30,
  },
  signatureLine: {
    width: '100%',
    height: 1,
    backgroundColor: '#8A8878',
  },
  statusActionsBox: {
    backgroundColor: Colors.card,
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: Colors.border,
    marginBottom: 30,
  },
  statusActionsTitle: {
    color: Colors.textPrimary,
    fontFamily: 'Cairo_600SemiBold',
    fontSize: 14,
    textAlign: 'right',
    marginBottom: 12,
  },
  statusButtonsRow: {
    flexDirection: 'row-reverse',
    gap: 10,
  },
  statusButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: 'center',
  },
  statusButtonActive: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  statusButtonText: {
    color: Colors.textMuted,
    fontFamily: 'Cairo_600SemiBold',
    fontSize: 13,
  },
  statusButtonTextActive: {
    color: '#fff',
  },
});
