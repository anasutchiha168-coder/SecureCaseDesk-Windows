// SECURECASEDESK_PHASE9_S2
import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View, Text, StyleSheet, FlatList, Pressable, Modal, TextInput, Alert,
  ActivityIndicator, ScrollView, KeyboardAvoidingView, Platform, I18nManager,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Plus, X, Search, ChevronDown, Check, Users, LogOut, ArrowLeftRight, Pencil } from 'lucide-react-native';
import * as Crypto from 'expo-crypto';
import { getDb } from '@/database/db';
import { Colors, Spacing, Radius, Fonts, FontSizes, Shadows } from '@/constants/theme';
import { useAuth } from '@/context/AuthContext';
import AttachmentsPanel from '@/components/attachments/AttachmentsPanel';
import { can, assertUserCan } from '@/security/permissions';

interface DetaineeRow {
  id: string;
  reference_number: string;
  full_name: string;
  admission_date: number;
  release_date: number | null;
  status: string;
  category_name: string | null;
}

interface CategoryRow {
  id: string;
  name: string;
}

const ROW: 'row' | 'row-reverse' = I18nManager.isRTL ? 'row' : 'row-reverse';
const DAY_MS = 24 * 60 * 60 * 1000;
const MONTHS = [
  'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
  'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
];
const ARABIC_DIGITS = '٠١٢٣٤٥٦٧٨٩';
const PERSIAN_DIGITS = '۰۱۲۳۴۵۶۷۸۹';

const SQL_BASE = `
  SELECT d.id, d.reference_number, d.full_name, d.admission_date,
         d.release_date, d.status, c.name AS category_name
  FROM detainees d
  LEFT JOIN detainee_categories c ON c.id = d.category_id
`;
const SQL_ORDER = ' ORDER BY d.admission_date DESC, d.created_at DESC';

function toArabicDigits(value: number | string): string {
  return String(value).replace(/[0-9]/g, (d) => ARABIC_DIGITS[Number(d)]);
}

function normalizeDigits(text: string): string {
  return text
    .replace(/[٠-٩]/g, (d) => String(ARABIC_DIGITS.indexOf(d)))
    .replace(/[۰-۹]/g, (d) => String(PERSIAN_DIGITS.indexOf(d)));
}

function formatDate(ts: number): string {
  const d = new Date(ts);
  return toArabicDigits(d.getDate()) + ' ' + MONTHS[d.getMonth()] + ' ' + toArabicDigits(d.getFullYear());
}

function durationText(admission: number, release: number | null): string {
  const end = release ?? Date.now();
  const days = Math.max(0, Math.floor((end - admission) / DAY_MS));
  if (days === 0) return 'أقل من يوم';
  if (days === 1) return 'يوم واحد';
  if (days === 2) return 'يومان';
  if (days <= 10) return toArabicDigits(days) + ' أيام';
  return toArabicDigits(days) + ' يوماً';
}

function parseDate(d: string, m: string, y: string): number | null {
  if (!/^[0-9]{1,2}$/.test(d) || !/^[0-9]{1,2}$/.test(m) || !/^[0-9]{4}$/.test(y)) return null;
  const dd = Number(d);
  const mm = Number(m);
  const yy = Number(y);
  if (yy < 1900 || yy > 2100) return null;
  const dt = new Date(yy, mm - 1, dd);
  if (dt.getFullYear() !== yy || dt.getMonth() !== mm - 1 || dt.getDate() !== dd) return null;
  return dt.getTime();
}

function endOfToday(): number {
  const t = new Date();
  t.setHours(23, 59, 59, 999);
  return t.getTime();
}

function todayParts() {
  const t = new Date();
  return { d: String(t.getDate()), m: String(t.getMonth() + 1), y: String(t.getFullYear()) };
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.infoRow}>
      <Text style={styles.infoLabel}>{label}</Text>
      <Text style={styles.infoValue}>{value}</Text>
    </View>
  );
}

function DetaineeCard({ item }: { item: DetaineeRow }) {
  const released = item.status === 'مفرج عنه';
  const badgeColor = released ? Colors.success : Colors.warning;
  return (
    <View style={styles.card}>
      <View style={styles.cardTop}>
        <Text style={styles.name} numberOfLines={2}>{item.full_name}</Text>
        <View style={[styles.badge, { backgroundColor: badgeColor + '22', borderColor: badgeColor }]}>
          <Text style={[styles.badgeText, { color: badgeColor }]}>{item.status}</Text>
        </View>
      </View>
      <InfoRow label="الرقم المرجعي" value={item.reference_number} />
      <InfoRow label="الفئة" value={item.category_name ?? 'غير محددة'} />
      <InfoRow label="تاريخ الدخول" value={formatDate(item.admission_date)} />
      {released && item.release_date !== null && (
        <InfoRow label="تاريخ الإفراج" value={formatDate(item.release_date)} />
      )}
      <InfoRow label="مدة الحجز" value={durationText(item.admission_date, item.release_date)} />
    </View>
  );
}

interface DetaineeDetail {
  id: string;
  reference_number: string;
  full_name: string;
  category_id: string;
  category_name: string | null;
  admission_date: number;
  release_date: number | null;
  alleged_offense: string;
  detaining_authority: string;
  status: string;
}

interface MovementRow {
  id: string;
  movement_number: string;
  movement_type: string;
  movement_date: number;
  previous_authority: string | null;
  new_authority: string | null;
  reason: string | null;
  executed_by_name: string | null;
}

type CorrectionField = 'full_name' | 'alleged_offense';

const CORRECTION_FIELDS: { key: CorrectionField; label: string }[] = [
  { key: 'full_name', label: 'الاسم الكامل' },
  { key: 'alleged_offense', label: 'التهمة المنسوبة' },
];

interface CorrectionRow {
  id: string;
  field_name: string;
  previous_value: string | null;
  new_value: string | null;
  reason: string;
  created_at: number;
  executed_by_name: string | null;
}

function fieldLabel(key: string): string {
  const f = CORRECTION_FIELDS.find((x) => x.key === key);
  return f ? f.label : key;
}

function authorityLabel(categoryName: string, authority: string): string {
  const a = authority.trim();
  if (categoryName && a) return categoryName + ' - ' + a;
  return categoryName || a;
}

function makeMovementNumber(): string {
  return 'MOV-' + Date.now() + '-' + Math.floor(1000 + Math.random() * 9000);
}

function movementColor(type: string): string {
  if (type === 'إيداع') return Colors.primaryLight;
  if (type === 'إفراج') return Colors.success;
  if (type === 'نقل') return Colors.warning;
  return Colors.textSecondary;
}

function MovementCard({ movement }: { movement: MovementRow }) {
  const color = movementColor(movement.movement_type);
  return (
    <View style={styles.moveCard}>
      <View style={styles.cardTop}>
        <View style={[styles.badge, { backgroundColor: color + '22', borderColor: color }]}>
          <Text style={[styles.badgeText, { color }]}>{movement.movement_type}</Text>
        </View>
        <Text style={styles.moveDate}>{formatDate(movement.movement_date)}</Text>
      </View>
      <InfoRow label="رقم الحركة" value={movement.movement_number} />
      {movement.previous_authority ? <InfoRow label="من" value={movement.previous_authority} /> : null}
      {movement.new_authority ? <InfoRow label="إلى" value={movement.new_authority} /> : null}
      {movement.reason ? <InfoRow label="السبب" value={movement.reason} /> : null}
      {movement.executed_by_name ? <InfoRow label="نفّذها" value={movement.executed_by_name} /> : null}
    </View>
  );
}

export default function DetaineesScreen() {
  const { user } = useAuth();
  const canAdd = can(user?.role, 'detainees.manage');

  const [items, setItems] = useState<DetaineeRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchText, setSearchText] = useState('');
  const [query, setQuery] = useState('');
  const requestId = useRef(0);

  const [showForm, setShowForm] = useState(false);
  const [showPicker, setShowPicker] = useState(false);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState('');
  const [categories, setCategories] = useState<CategoryRow[]>([]);

  const [fullName, setFullName] = useState('');
  const [refNumber, setRefNumber] = useState('');
  const [offense, setOffense] = useState('');
  const [authority, setAuthority] = useState('');
  const [categoryId, setCategoryId] = useState<string | null>(null);
  const [day, setDay] = useState('');
  const [month, setMonth] = useState('');
  const [year, setYear] = useState('');

  const loadDetainees = useCallback(async (q: string) => {
    const current = ++requestId.current;
    try {
      const db = await getDb();
      const term = q.trim();
      const rows = term
        ? await db.getAllAsync<DetaineeRow>(
            SQL_BASE + ' WHERE d.full_name LIKE ? OR d.reference_number LIKE ?' + SQL_ORDER,
            ['%' + term + '%', '%' + term + '%']
          )
        : await db.getAllAsync<DetaineeRow>(SQL_BASE + SQL_ORDER);
      if (current === requestId.current) setItems(rows);
    } catch (e) {
      console.error('[Detainees] load error:', e);
      if (current === requestId.current) Alert.alert('خطأ', 'تعذر تحميل بيانات المحتجزين');
    } finally {
      if (current === requestId.current) setLoading(false);
    }
  }, []);

  useEffect(() => {
    const t = setTimeout(() => setQuery(normalizeDigits(searchText)), 300);
    return () => clearTimeout(t);
  }, [searchText]);

  useEffect(() => {
    loadDetainees(query);
  }, [query, loadDetainees]);

  const resetForm = () => {
    const t = todayParts();
    setFullName('');
    setRefNumber('');
    setOffense('');
    setAuthority('');
    setCategoryId(null);
    setDay(t.d);
    setMonth(t.m);
    setYear(t.y);
    setFormError('');
  };

  const openForm = async () => {
    if (!canAdd) return;
    try {
      const db = await getDb();
      const rows = await db.getAllAsync<CategoryRow>(
        'SELECT id, name FROM detainee_categories WHERE is_active = 1 ORDER BY rowid'
      );
      setCategories(rows);
    } catch (e) {
      console.error('[Detainees] categories error:', e);
      Alert.alert('خطأ', 'تعذر تحميل فئات المحتجزين');
      return;
    }
    resetForm();
    setShowForm(true);
  };

  const closeForm = () => {
    if (saving) return;
    setShowPicker(false);
    setShowForm(false);
  };

  const handleSave = async () => {
    if (saving) return;
    if (!canAdd || !user) {
      setFormError('ليست لديك صلاحية تسجيل المحتجزين');
      return;
    }

    const name = fullName.trim();
    const ref = normalizeDigits(refNumber.trim());
    const alleged = offense.trim();
    const detainingAuthority = authority.trim();

    if (!name) { setFormError('الاسم الكامل مطلوب'); return; }
    if (!ref) { setFormError('الرقم المرجعي مطلوب'); return; }
    if (!alleged) { setFormError('التهمة المنسوبة مطلوبة'); return; }
    if (!categoryId) { setFormError('اختر فئة المحتجز'); return; }

    const admissionTs = parseDate(normalizeDigits(day.trim()), normalizeDigits(month.trim()), normalizeDigits(year.trim()));
    if (admissionTs === null) {
      setFormError('تاريخ الدخول غير صحيح، تأكد من اليوم والشهر والسنة');
      return;
    }
    if (admissionTs > endOfToday()) {
      setFormError('تاريخ الدخول لا يمكن أن يكون في المستقبل');
      return;
    }

    setSaving(true);
    setFormError('');
    try {
      const db = await getDb();
      await assertUserCan(db, user.id, 'detainees.manage');
      const dup = await db.getFirstAsync<{ id: string }>(
        'SELECT id FROM detainees WHERE reference_number = ?',
        [ref]
      );
      if (dup) {
        setFormError('الرقم المرجعي مستخدم لمحتجز آخر');
        return;
      }

      const detaineeId = Crypto.randomUUID();
      const movementId = Crypto.randomUUID();
      const now = Date.now();
      const movementNumber = 'MOV-' + now + '-' + Math.floor(1000 + Math.random() * 9000);

      await db.withTransactionAsync(async () => {
        await db.runAsync(
          `INSERT INTO detainees
             (id, reference_number, full_name, category_id, admission_date,
              alleged_offense, detaining_authority, status, created_by, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [detaineeId, ref, name, categoryId, admissionTs, alleged, detainingAuthority, 'محتجز', user.id, now, now]
        );
        await db.runAsync(
          `INSERT INTO detainee_movements
             (id, movement_number, detainee_id, movement_type, movement_date,
              previous_authority, new_authority, executed_by, reason, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            movementId, movementNumber, detaineeId, 'إيداع', admissionTs,
            null,
            authorityLabel(categories.find((c) => c.id === categoryId)?.name ?? '', detainingAuthority) || null,
            user.id, 'تسجيل دخول المحتجز', now,
          ]
        );
      });

      setShowPicker(false);
      setShowForm(false);
      await loadDetainees(query);
      Alert.alert('تم الحفظ', 'تم تسجيل المحتجز وإضافة حركة الإيداع بنجاح');
    } catch (e) {
      console.error('[Detainees] save error:', e);
      const msg = String((e as Error)?.message ?? '');
      if (msg.includes('FORBIDDEN')) {
        setFormError('ليست لديك صلاحية تسجيل المحتجزين');
      } else if (msg.includes('UNIQUE') && msg.includes('reference_number')) {
        setFormError('الرقم المرجعي مستخدم لمحتجز آخر');
      } else {
        setFormError('تعذر الحفظ ولم يتم تسجيل أي بيانات، حاول مرة أخرى');
      }
    } finally {
      setSaving(false);
    }
  };

  const [showDetail, setShowDetail] = useState(false);
  const [detailLoading, setDetailLoading] = useState(false);
  const [detail, setDetail] = useState<DetaineeDetail | null>(null);
  const [movements, setMovements] = useState<MovementRow[]>([]);
  const [action, setAction] = useState<'release' | 'transfer' | null>(null);
  const [showTransferPicker, setShowTransferPicker] = useState(false);
  const [aSaving, setASaving] = useState(false);
  const [aError, setAError] = useState('');
  const [aDay, setADay] = useState('');
  const [aMonth, setAMonth] = useState('');
  const [aYear, setAYear] = useState('');
  const [aReason, setAReason] = useState('');
  const [aAuthority, setAAuthority] = useState('');
  const [aCategoryId, setACategoryId] = useState<string | null>(null);
  const [corrections, setCorrections] = useState<CorrectionRow[]>([]);
  const [showCorrection, setShowCorrection] = useState(false);
  const [cField, setCField] = useState<CorrectionField>('full_name');
  const [cValue, setCValue] = useState('');
  const [cReason, setCReason] = useState('');
  const [cSaving, setCSaving] = useState(false);
  const [cError, setCError] = useState('');

  const loadDetail = async (id: string) => {
    const db = await getDb();
    const row = await db.getFirstAsync<DetaineeDetail>(
      `SELECT d.id, d.reference_number, d.full_name, d.category_id, d.admission_date,
              d.release_date, d.alleged_offense, d.detaining_authority, d.status,
              c.name AS category_name
       FROM detainees d
       LEFT JOIN detainee_categories c ON c.id = d.category_id
       WHERE d.id = ?`,
      [id]
    );
    if (!row) throw new Error('NOT_FOUND');
    const moves = await db.getAllAsync<MovementRow>(
      `SELECT m.id, m.movement_number, m.movement_type, m.movement_date,
              m.previous_authority, m.new_authority, m.reason, u.username AS executed_by_name
       FROM detainee_movements m
       LEFT JOIN users u ON u.id = m.executed_by
       WHERE m.detainee_id = ?
       ORDER BY m.movement_date DESC, m.created_at DESC, m.rowid DESC`,
      [id]
    );
    const corr = await db.getAllAsync<CorrectionRow>(
      `SELECT h.id, h.field_name, h.previous_value, h.new_value, h.reason, h.created_at,
              u.username AS executed_by_name
       FROM correction_history h
       LEFT JOIN users u ON u.id = h.executed_by
       WHERE h.detainee_id = ?
       ORDER BY h.created_at DESC, h.rowid DESC`,
      [id]
    );
    setDetail(row);
    setMovements(moves);
    setCorrections(corr);
  };

  const refreshAfterAction = async (id: string) => {
    try {
      await loadDetail(id);
      await loadDetainees(query);
    } catch (e) {
      console.error('[Detainees] refresh error:', e);
    }
  };

  const openDetail = async (id: string) => {
    setDetail(null);
    setMovements([]);
    setShowDetail(true);
    setDetailLoading(true);
    try {
      await loadDetail(id);
    } catch (e) {
      console.error('[Detainees] detail error:', e);
      setShowDetail(false);
      Alert.alert('خطأ', 'تعذر تحميل بيانات المحتجز');
    } finally {
      setDetailLoading(false);
    }
  };

  const closeDetail = () => {
    if (aSaving) return;
    setAction(null);
    setShowTransferPicker(false);
    setShowDetail(false);
    setDetail(null);
    setMovements([]);
  };

  const openAction = async (type: 'release' | 'transfer') => {
    if (!canAdd || !detail) return;
    if (detail.status !== 'محتجز') {
      Alert.alert('تنبيه', 'هذا المحتجز مفرج عنه مسبقاً');
      return;
    }
    if (type === 'transfer') {
      try {
        const db = await getDb();
        const rows = await db.getAllAsync<CategoryRow>(
          'SELECT id, name FROM detainee_categories WHERE is_active = 1 ORDER BY rowid'
        );
        setCategories(rows);
      } catch (e) {
        console.error('[Detainees] categories error:', e);
        Alert.alert('خطأ', 'تعذر تحميل فئات المحتجزين');
        return;
      }
    }
    const t = todayParts();
    setADay(t.d);
    setAMonth(t.m);
    setAYear(t.y);
    setAReason('');
    setAError('');
    setAAuthority(detail.detaining_authority);
    setACategoryId(detail.category_id);
    setAction(type);
  };

  const closeAction = () => {
    if (aSaving) return;
    setShowTransferPicker(false);
    setAction(null);
  };

  const persistAction = async (
    ts: number,
    reason: string,
    target: CategoryRow | null,
    newAuthority: string
  ) => {
    if (!action || !detail || !user || !canAdd) return;
    const type = action;
    setASaving(true);
    setAError('');
    try {
      const db = await getDb();
      await assertUserCan(db, user.id, 'detainees.manage');
      const last = await db.getFirstAsync<{ last_date: number | null }>(
        'SELECT MAX(movement_date) AS last_date FROM detainee_movements WHERE detainee_id = ?',
        [detail.id]
      );
      if (last && last.last_date !== null && ts < last.last_date) {
        setAError('التاريخ لا يمكن أن يسبق آخر حركة مسجلة بتاريخ ' + formatDate(last.last_date));
        return;
      }

      const now = Date.now();
      const previousLabel = authorityLabel(detail.category_name ?? '', detail.detaining_authority);
      const nextLabel = type === 'transfer' && target ? authorityLabel(target.name, newAuthority) : null;

      await db.withTransactionAsync(async () => {
        if (type === 'release') {
          const res = await db.runAsync(
            `UPDATE detainees SET status = 'مفرج عنه', release_date = ?, updated_at = ?
             WHERE id = ? AND status = 'محتجز' AND release_date IS NULL`,
            [ts, now, detail.id]
          );
          if (res.changes === 0) throw new Error('STATE_CHANGED');
        } else {
          if (!target) throw new Error('NO_TARGET');
          const res = await db.runAsync(
            `UPDATE detainees SET category_id = ?, detaining_authority = ?, updated_at = ?
             WHERE id = ? AND status = 'محتجز'`,
            [target.id, newAuthority, now, detail.id]
          );
          if (res.changes === 0) throw new Error('STATE_CHANGED');
        }
        await db.runAsync(
          `INSERT INTO detainee_movements
             (id, movement_number, detainee_id, movement_type, movement_date,
              previous_authority, new_authority, executed_by, reason, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            Crypto.randomUUID(), makeMovementNumber(), detail.id,
            type === 'release' ? 'إفراج' : 'نقل', ts,
            previousLabel || null, nextLabel || null, user.id,
            reason || (type === 'release' ? 'إفراج عن المحتجز' : 'نقل المحتجز'), now,
          ]
        );
      });

      setShowTransferPicker(false);
      setAction(null);
      await refreshAfterAction(detail.id);
      Alert.alert('تم الحفظ', type === 'release' ? 'تم تسجيل الإفراج بنجاح' : 'تم تسجيل النقل بنجاح');
    } catch (e) {
      console.error('[Detainees] action error:', e);
      const msg = String((e as Error)?.message ?? '');
      if (msg.includes('FORBIDDEN')) {
        setAError('ليست لديك صلاحية تنفيذ هذا الإجراء');
      } else if (msg.includes('STATE_CHANGED')) {
        setAError('تغيّرت حالة المحتجز ولم يتم تسجيل أي حركة');
        await refreshAfterAction(detail.id);
      } else if (msg.includes('CHECK constraint')) {
        setAError('التاريخ غير مقبول، ولم يتم تسجيل أي حركة');
      } else {
        setAError('تعذر الحفظ ولم يتم تسجيل أي بيانات، حاول مرة أخرى');
      }
    } finally {
      setASaving(false);
    }
  };

  const submitAction = () => {
    if (aSaving || !action || !detail) return;
    if (!canAdd || !user) {
      setAError('ليست لديك صلاحية تنفيذ هذا الإجراء');
      return;
    }
    if (detail.status !== 'محتجز') {
      setAError('هذا المحتجز مفرج عنه مسبقاً');
      return;
    }

    const ts = parseDate(normalizeDigits(aDay.trim()), normalizeDigits(aMonth.trim()), normalizeDigits(aYear.trim()));
    if (ts === null) {
      setAError('التاريخ غير صحيح، تأكد من اليوم والشهر والسنة');
      return;
    }
    if (ts > endOfToday()) {
      setAError('التاريخ لا يمكن أن يكون في المستقبل');
      return;
    }
    if (ts < detail.admission_date) {
      setAError('التاريخ لا يمكن أن يسبق تاريخ الدخول (' + formatDate(detail.admission_date) + ')');
      return;
    }

    const newAuthority = aAuthority.trim();
    let target: CategoryRow | null = null;
    if (action === 'transfer') {
      target =
        categories.find((c) => c.id === aCategoryId) ??
        (aCategoryId === detail.category_id
          ? { id: detail.category_id, name: detail.category_name ?? '' }
          : null);
      if (!target) {
        setAError('اختر الفئة الجديدة');
        return;
      }
      if (target.id === detail.category_id && newAuthority === detail.detaining_authority) {
        setAError('لم يتم تغيير الفئة أو جهة الحجز');
        return;
      }
    }

    setAError('');
    const reason = aReason.trim();
    const chosenTarget = target;
    Alert.alert(
      action === 'release' ? 'تأكيد الإفراج' : 'تأكيد النقل',
      'سيتم تسجيل الحركة في السجل التاريخي ولا يمكن حذفها لاحقاً. هل تريد المتابعة؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        { text: 'تأكيد', onPress: () => persistAction(ts, reason, chosenTarget, newAuthority) },
      ]
    );
  };

  const selectedCategory = categories.find((c) => c.id === categoryId);
  const transferCategoryName =
    categories.find((c) => c.id === aCategoryId)?.name ??
    (detail && aCategoryId === detail.category_id ? detail.category_name : null);

  const canCorrect = can(user?.role, 'detainees.correct');

  const currentFieldValue = (field: CorrectionField): string => {
    if (!detail) return '';
    return field === 'full_name' ? detail.full_name : detail.alleged_offense;
  };

  const openCorrection = () => {
    if (!canCorrect || !detail) return;
    setCField('full_name');
    setCValue(detail.full_name);
    setCReason('');
    setCError('');
    setShowCorrection(true);
  };

  const closeCorrection = () => {
    if (cSaving) return;
    setShowCorrection(false);
  };

  const selectCorrectionField = (field: CorrectionField) => {
    if (cSaving) return;
    setCField(field);
    setCValue(currentFieldValue(field));
    setCError('');
  };

  const persistCorrection = async (
    field: CorrectionField,
    previous: string,
    next: string,
    reason: string
  ) => {
    if (!detail || !user || !canCorrect) return;
    const detaineeId = detail.id;
    const userId = user.id;
    setCSaving(true);
    setCError('');
    try {
      const db = await getDb();
      const now = Date.now();
      const d = new Date();
      const startOfToday = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();

      await db.withTransactionAsync(async () => {
        await assertUserCan(db, userId, 'detainees.correct');

        const current = await db.getFirstAsync<{ value: string | null }>(
          field === 'full_name'
            ? 'SELECT full_name AS value FROM detainees WHERE id = ?'
            : 'SELECT alleged_offense AS value FROM detainees WHERE id = ?',
          [detaineeId]
        );
        if (!current) throw new Error('NOT_FOUND');
        if ((current.value ?? '') !== previous) throw new Error('VALUE_CHANGED');

        const res =
          field === 'full_name'
            ? await db.runAsync(
                'UPDATE detainees SET full_name = ?, updated_at = ? WHERE id = ?',
                [next, now, detaineeId]
              )
            : await db.runAsync(
                'UPDATE detainees SET alleged_offense = ?, updated_at = ? WHERE id = ?',
                [next, now, detaineeId]
              );
        if (res.changes === 0) throw new Error('NOT_FOUND');

        const original = await db.getFirstAsync<{ id: string }>(
          `SELECT id FROM detainee_movements
           WHERE detainee_id = ? AND movement_type = ?
           ORDER BY movement_date ASC, created_at ASC, rowid ASC LIMIT 1`,
          [detaineeId, 'إيداع']
        );
        const last = await db.getFirstAsync<{ last_date: number | null }>(
          'SELECT MAX(movement_date) AS last_date FROM detainee_movements WHERE detainee_id = ?',
          [detaineeId]
        );
        const moveDate = Math.max(startOfToday, last?.last_date ?? 0);
        const movementId = Crypto.randomUUID();

        await db.runAsync(
          `INSERT INTO detainee_movements
             (id, movement_number, detainee_id, movement_type, movement_date,
              previous_authority, new_authority, executed_by, reason, related_movement_id, created_at)
           VALUES (?, ?, ?, ?, ?, NULL, NULL, ?, ?, ?, ?)`,
          [
            movementId, makeMovementNumber(), detaineeId, 'تصحيح', moveDate,
            userId, 'تصحيح ' + fieldLabel(field) + ': ' + reason, original?.id ?? null, now,
          ]
        );

        await db.runAsync(
          `INSERT INTO correction_history
             (id, detainee_id, field_name, previous_value, new_value, reason,
              executed_by, related_movement_id, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [Crypto.randomUUID(), detaineeId, field, previous, next, reason, userId, movementId, now]
        );
      });

      setShowCorrection(false);
      await refreshAfterAction(detaineeId);
      Alert.alert('تم الحفظ', 'تم تسجيل التصحيح وحفظ القيمة السابقة في السجل');
    } catch (e) {
      console.error('[Detainees] correction error:', e);
      const msg = String((e as Error)?.message ?? '');
      if (msg.includes('FORBIDDEN')) {
        setCError('التصحيح من صلاحيات المدير فقط');
      } else if (msg.includes('VALUE_CHANGED')) {
        setCError('تغيّرت القيمة الحالية، تم تحديث البيانات، راجعها وأعد المحاولة');
        await refreshAfterAction(detaineeId);
      } else {
        setCError('تعذر الحفظ ولم يتم تسجيل أي بيانات، حاول مرة أخرى');
      }
    } finally {
      setCSaving(false);
    }
  };

  const submitCorrection = () => {
    if (cSaving || !detail) return;
    if (!canCorrect || !user) {
      setCError('التصحيح من صلاحيات المدير فقط');
      return;
    }
    const previous = currentFieldValue(cField);
    const next = cValue.trim();
    const reason = cReason.trim();
    if (next === '') {
      setCError('القيمة الجديدة مطلوبة');
      return;
    }
    if (next === previous) {
      setCError('القيمة الجديدة مطابقة للقيمة الحالية');
      return;
    }
    if (reason === '') {
      setCError('سبب التصحيح مطلوب');
      return;
    }
    setCError('');
    const field = cField;
    Alert.alert(
      'تأكيد التصحيح',
      'ستُحفظ القيمة السابقة في سجل التصحيحات ولا يمكن تعديله أو حذفه لاحقاً. هل تريد المتابعة؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        { text: 'تأكيد', onPress: () => persistCorrection(field, previous, next, reason) },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>المحتجزون</Text>
          <Text style={styles.headerSub}>العدد: {toArabicDigits(items.length)}</Text>
        </View>
        {canAdd && (
          <Pressable
            onPress={openForm}
            style={({ pressed }) => [styles.addBtn, pressed && { opacity: 0.85 }]}
          >
            <Plus size={22} color={Colors.textOnPrimary} />
          </Pressable>
        )}
      </View>

      <View style={styles.searchBox}>
        <Search size={18} color={Colors.textSecondary} />
        <TextInput
          style={styles.searchInput}
          placeholder="ابحث بالاسم أو الرقم المرجعي"
          placeholderTextColor={Colors.textMuted}
          value={searchText}
          onChangeText={setSearchText}
        />
      </View>

      {loading ? (
        <ActivityIndicator color={Colors.primary} style={{ marginTop: Spacing.xxl }} />
      ) : (
        <FlatList
          data={items}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <Pressable
              onPress={() => openDetail(item.id)}
              style={({ pressed }) => (pressed ? { opacity: 0.85 } : undefined)}
            >
              <DetaineeCard item={item} />
            </Pressable>
          )}
          contentContainerStyle={styles.listContent}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Users size={40} color={Colors.textMuted} />
              <Text style={styles.emptyText}>
                {query ? 'لا توجد نتائج مطابقة' : 'لا يوجد محتجزون مسجلون بعد'}
              </Text>
            </View>
          }
        />
      )}

      <Modal visible={showForm} transparent animationType="slide" statusBarTranslucent onRequestClose={closeForm}>
        <KeyboardAvoidingView
          style={styles.overlay}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        >
          <View style={styles.sheet}>
            <View style={styles.sheetHeader}>
              <Text style={styles.sheetTitle}>تسجيل محتجز جديد</Text>
              <Pressable onPress={closeForm} style={styles.closeBtn}>
                <X size={20} color={Colors.textSecondary} />
              </Pressable>
            </View>

            <ScrollView
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={{ padding: Spacing.lg, paddingBottom: Spacing.xxl }}
            >
              <Text style={styles.label}>الاسم الكامل *</Text>
              <TextInput
                style={styles.input}
                value={fullName}
                onChangeText={setFullName}
                placeholder="الاسم الرباعي"
                placeholderTextColor={Colors.textMuted}
              />

              <Text style={styles.label}>الرقم المرجعي *</Text>
              <TextInput
                style={styles.input}
                value={refNumber}
                onChangeText={setRefNumber}
                placeholder="الرقم المرجعي الفريد"
                placeholderTextColor={Colors.textMuted}
                autoCapitalize="characters"
              />

              <Text style={styles.label}>التهمة المنسوبة *</Text>
              <TextInput
                style={styles.input}
                value={offense}
                onChangeText={setOffense}
                placeholder="التهمة"
                placeholderTextColor={Colors.textMuted}
              />

              <Text style={styles.label}>جهة الحجز</Text>
              <TextInput
                style={styles.input}
                value={authority}
                onChangeText={setAuthority}
                placeholder="اختياري"
                placeholderTextColor={Colors.textMuted}
              />

              <Text style={styles.label}>الفئة *</Text>
              <Pressable style={styles.selector} onPress={() => setShowPicker(true)}>
                <Text
                  style={[styles.selectorText, !selectedCategory && { color: Colors.textMuted }]}
                  numberOfLines={1}
                >
                  {selectedCategory ? selectedCategory.name : 'اختر الفئة'}
                </Text>
                <ChevronDown size={18} color={Colors.textSecondary} />
              </Pressable>

              <Text style={styles.label}>تاريخ الدخول *</Text>
              <View style={styles.dateRow}>
                <TextInput
                  style={[styles.input, styles.dateInput]}
                  value={day}
                  onChangeText={setDay}
                  placeholder="يوم"
                  placeholderTextColor={Colors.textMuted}
                  keyboardType="number-pad"
                  maxLength={2}
                />
                <TextInput
                  style={[styles.input, styles.dateInput]}
                  value={month}
                  onChangeText={setMonth}
                  placeholder="شهر"
                  placeholderTextColor={Colors.textMuted}
                  keyboardType="number-pad"
                  maxLength={2}
                />
                <TextInput
                  style={[styles.input, styles.dateInput, { flex: 1.6 }]}
                  value={year}
                  onChangeText={setYear}
                  placeholder="سنة"
                  placeholderTextColor={Colors.textMuted}
                  keyboardType="number-pad"
                  maxLength={4}
                />
              </View>

              {formError !== '' && <Text style={styles.errorText}>{formError}</Text>}

              <Pressable
                onPress={handleSave}
                disabled={saving}
                style={({ pressed }) => [styles.saveBtn, (pressed || saving) && { opacity: 0.8 }]}
              >
                {saving ? (
                  <ActivityIndicator color={Colors.textOnPrimary} />
                ) : (
                  <Text style={styles.saveBtnText}>حفظ</Text>
                )}
              </Pressable>
              <Pressable onPress={closeForm} style={styles.cancelBtn}>
                <Text style={styles.cancelBtnText}>إلغاء</Text>
              </Pressable>
            </ScrollView>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      <Modal visible={showPicker} transparent animationType="fade" statusBarTranslucent onRequestClose={() => setShowPicker(false)}>
        <Pressable style={styles.pickerOverlay} onPress={() => setShowPicker(false)}>
          <View style={styles.pickerCard}>
            <Text style={styles.sheetTitle}>اختر الفئة</Text>
            <ScrollView style={{ marginTop: Spacing.md }}>
              {categories.map((c) => {
                const selected = c.id === categoryId;
                return (
                  <Pressable
                    key={c.id}
                    style={styles.pickerItem}
                    onPress={() => {
                      setCategoryId(c.id);
                      setShowPicker(false);
                    }}
                  >
                    <Text
                      style={[styles.pickerItemText, selected && { color: Colors.primaryLight, fontFamily: Fonts.bold }]}
                    >
                      {c.name}
                    </Text>
                    {selected && <Check size={18} color={Colors.primaryLight} />}
                  </Pressable>
                );
              })}
            </ScrollView>
          </View>
        </Pressable>
      </Modal>

      <Modal visible={showDetail} transparent animationType="slide" statusBarTranslucent onRequestClose={closeDetail}>
        <View style={styles.overlay}>
          <View style={[styles.sheet, { height: '92%' }]}>
            <View style={styles.sheetHeader}>
              <Text style={styles.sheetTitle}>تفاصيل المحتجز</Text>
              <Pressable onPress={closeDetail} style={styles.closeBtn}>
                <X size={20} color={Colors.textSecondary} />
              </Pressable>
            </View>

            {detailLoading || !detail ? (
              <ActivityIndicator color={Colors.primary} style={{ marginTop: Spacing.xxl }} />
            ) : (
              <FlatList
                style={{ flex: 1 }}
                data={movements}
                keyExtractor={(m) => m.id}
                contentContainerStyle={{ padding: Spacing.lg, paddingBottom: Spacing.xxl, gap: Spacing.sm }}
                renderItem={({ item: m }) => <MovementCard movement={m} />}
                ListEmptyComponent={<Text style={styles.emptyText}>لا توجد حركات مسجلة</Text>}
                ListHeaderComponent={
                  <View style={{ gap: Spacing.sm }}>
                    <View style={styles.cardTop}>
                      <Text style={styles.name} numberOfLines={3}>{detail.full_name}</Text>
                      <View
                        style={[
                          styles.badge,
                          {
                            backgroundColor: (detail.status === 'مفرج عنه' ? Colors.success : Colors.warning) + '22',
                            borderColor: detail.status === 'مفرج عنه' ? Colors.success : Colors.warning,
                          },
                        ]}
                      >
                        <Text
                          style={[
                            styles.badgeText,
                            { color: detail.status === 'مفرج عنه' ? Colors.success : Colors.warning },
                          ]}
                        >
                          {detail.status}
                        </Text>
                      </View>
                    </View>
                    <InfoRow label="الرقم المرجعي" value={detail.reference_number} />
                    <InfoRow label="الفئة" value={detail.category_name ?? 'غير محددة'} />
                    <InfoRow label="التهمة المنسوبة" value={detail.alleged_offense} />
                    {detail.detaining_authority !== '' && (
                      <InfoRow label="جهة الحجز" value={detail.detaining_authority} />
                    )}
                    <InfoRow label="تاريخ الدخول" value={formatDate(detail.admission_date)} />
                    {detail.release_date !== null && (
                      <InfoRow label="تاريخ الإفراج" value={formatDate(detail.release_date)} />
                    )}
                    <InfoRow label="مدة الحجز" value={durationText(detail.admission_date, detail.release_date)} />

                    {canAdd && detail.status === 'محتجز' && (
                      <View style={styles.actionsRow}>
                        <Pressable
                          style={[styles.actionBtn, { backgroundColor: Colors.success }]}
                          onPress={() => openAction('release')}
                        >
                          <LogOut size={18} color={Colors.textOnPrimary} />
                          <Text style={styles.actionBtnText}>إفراج</Text>
                        </Pressable>
                        <Pressable
                          style={[styles.actionBtn, { backgroundColor: Colors.primary }]}
                          onPress={() => openAction('transfer')}
                        >
                          <ArrowLeftRight size={18} color={Colors.textOnPrimary} />
                          <Text style={styles.actionBtnText}>نقل</Text>
                        </Pressable>
                      </View>
                    )}

                    {canCorrect && (
                      <Pressable style={styles.corrBtn} onPress={openCorrection}>
                        <Pencil size={18} color={Colors.warning} />
                        <Text style={styles.corrBtnText}>تصحيح بيانات</Text>
                      </Pressable>
                    )}

                    {corrections.length > 0 && (
                      <>
                        <Text style={styles.sectionTitle}>سجل التصحيحات ({toArabicDigits(corrections.length)})</Text>
                        {corrections.map((c) => (
                          <View key={c.id} style={styles.corrCard}>
                            <View style={styles.cardTop}>
                              <Text style={styles.moveDate}>{fieldLabel(c.field_name)}</Text>
                              <Text style={styles.moveDate}>{formatDate(c.created_at)}</Text>
                            </View>
                            <InfoRow label="القيمة السابقة" value={c.previous_value ?? ''} />
                            <InfoRow label="القيمة الجديدة" value={c.new_value ?? ''} />
                            <InfoRow label="السبب" value={c.reason} />
                            {c.executed_by_name ? <InfoRow label="نفّذه" value={c.executed_by_name} /> : null}
                          </View>
                        ))}
                      </>
                    )}

                    <AttachmentsPanel entityType="detainee" entityId={detail.id} />

                    <Text style={styles.sectionTitle}>سجل الحركات ({toArabicDigits(movements.length)})</Text>
                  </View>
                }
              />
            )}
          </View>
        </View>
      </Modal>

      <Modal visible={action !== null} transparent animationType="slide" statusBarTranslucent onRequestClose={closeAction}>
        <KeyboardAvoidingView
          style={styles.overlay}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        >
          <View style={styles.sheet}>
            <View style={styles.sheetHeader}>
              <Text style={styles.sheetTitle}>{action === 'release' ? 'تسجيل إفراج' : 'تسجيل نقل'}</Text>
              <Pressable onPress={closeAction} style={styles.closeBtn}>
                <X size={20} color={Colors.textSecondary} />
              </Pressable>
            </View>

            <ScrollView
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={{ padding: Spacing.lg, paddingBottom: Spacing.xxl }}
            >
              {action === 'transfer' && (
                <>
                  <Text style={styles.label}>الفئة الجديدة *</Text>
                  <Pressable style={styles.selector} onPress={() => setShowTransferPicker(true)}>
                    <Text
                      style={[styles.selectorText, !transferCategoryName && { color: Colors.textMuted }]}
                      numberOfLines={1}
                    >
                      {transferCategoryName ? transferCategoryName : 'اختر الفئة'}
                    </Text>
                    <ChevronDown size={18} color={Colors.textSecondary} />
                  </Pressable>

                  <Text style={styles.label}>جهة الحجز الجديدة</Text>
                  <TextInput
                    style={styles.input}
                    value={aAuthority}
                    onChangeText={setAAuthority}
                    placeholder="اختياري"
                    placeholderTextColor={Colors.textMuted}
                  />
                </>
              )}

              <Text style={styles.label}>{action === 'release' ? 'تاريخ الإفراج *' : 'تاريخ النقل *'}</Text>
              <View style={styles.dateRow}>
                <TextInput
                  style={[styles.input, styles.dateInput]}
                  value={aDay}
                  onChangeText={setADay}
                  placeholder="يوم"
                  placeholderTextColor={Colors.textMuted}
                  keyboardType="number-pad"
                  maxLength={2}
                />
                <TextInput
                  style={[styles.input, styles.dateInput]}
                  value={aMonth}
                  onChangeText={setAMonth}
                  placeholder="شهر"
                  placeholderTextColor={Colors.textMuted}
                  keyboardType="number-pad"
                  maxLength={2}
                />
                <TextInput
                  style={[styles.input, styles.dateInput, { flex: 1.6 }]}
                  value={aYear}
                  onChangeText={setAYear}
                  placeholder="سنة"
                  placeholderTextColor={Colors.textMuted}
                  keyboardType="number-pad"
                  maxLength={4}
                />
              </View>

              <Text style={styles.label}>السبب</Text>
              <TextInput
                style={styles.input}
                value={aReason}
                onChangeText={setAReason}
                placeholder="اختياري"
                placeholderTextColor={Colors.textMuted}
              />

              {aError !== '' && <Text style={styles.errorText}>{aError}</Text>}

              <Pressable
                onPress={submitAction}
                disabled={aSaving}
                style={({ pressed }) => [
                  styles.saveBtn,
                  action === 'release' && { backgroundColor: Colors.success },
                  (pressed || aSaving) && { opacity: 0.8 },
                ]}
              >
                {aSaving ? (
                  <ActivityIndicator color={Colors.textOnPrimary} />
                ) : (
                  <Text style={styles.saveBtnText}>{action === 'release' ? 'تسجيل الإفراج' : 'تسجيل النقل'}</Text>
                )}
              </Pressable>
              <Pressable onPress={closeAction} style={styles.cancelBtn}>
                <Text style={styles.cancelBtnText}>إلغاء</Text>
              </Pressable>
            </ScrollView>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      <Modal visible={showTransferPicker} transparent animationType="fade" statusBarTranslucent onRequestClose={() => setShowTransferPicker(false)}>
        <Pressable style={styles.pickerOverlay} onPress={() => setShowTransferPicker(false)}>
          <View style={styles.pickerCard}>
            <Text style={styles.sheetTitle}>اختر الفئة الجديدة</Text>
            <ScrollView style={{ marginTop: Spacing.md }}>
              {categories.map((c) => {
                const selected = c.id === aCategoryId;
                return (
                  <Pressable
                    key={c.id}
                    style={styles.pickerItem}
                    onPress={() => {
                      setACategoryId(c.id);
                      setShowTransferPicker(false);
                    }}
                  >
                    <Text
                      style={[styles.pickerItemText, selected && { color: Colors.primaryLight, fontFamily: Fonts.bold }]}
                    >
                      {c.name}
                    </Text>
                    {selected && <Check size={18} color={Colors.primaryLight} />}
                  </Pressable>
                );
              })}
            </ScrollView>
          </View>
        </Pressable>
      </Modal>

      <Modal visible={showCorrection} transparent animationType="slide" statusBarTranslucent onRequestClose={closeCorrection}>
        <KeyboardAvoidingView
          style={styles.overlay}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        >
          <View style={styles.sheet}>
            <View style={styles.sheetHeader}>
              <Text style={styles.sheetTitle}>تصحيح بيانات المحتجز</Text>
              <Pressable onPress={closeCorrection} style={styles.closeBtn}>
                <X size={20} color={Colors.textSecondary} />
              </Pressable>
            </View>

            <ScrollView
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={{ padding: Spacing.lg, paddingBottom: Spacing.xxl }}
            >
              <Text style={styles.noteText}>
                لا تُحذف القيمة القديمة، بل تُحفظ في سجل التصحيحات مع السبب واسم المنفّذ، ولا يمكن تعديل السجل أو حذفه.
              </Text>

              <Text style={styles.label}>الحقل المراد تصحيحه</Text>
              <View style={styles.chipsRow}>
                {CORRECTION_FIELDS.map((f) => {
                  const active = f.key === cField;
                  return (
                    <Pressable
                      key={f.key}
                      style={[
                        styles.chip,
                        active && { borderColor: Colors.primary, backgroundColor: Colors.primary + '22' },
                      ]}
                      onPress={() => selectCorrectionField(f.key)}
                    >
                      <Text
                        style={[styles.chipText, active && { color: Colors.primaryLight, fontFamily: Fonts.bold }]}
                      >
                        {f.label}
                      </Text>
                    </Pressable>
                  );
                })}
              </View>

              <Text style={styles.label}>القيمة الحالية</Text>
              <Text style={styles.noteText}>{currentFieldValue(cField)}</Text>

              <Text style={styles.label}>القيمة الجديدة *</Text>
              <TextInput
                style={styles.input}
                value={cValue}
                onChangeText={setCValue}
                placeholder="القيمة الصحيحة"
                placeholderTextColor={Colors.textMuted}
              />

              <Text style={styles.label}>سبب التصحيح *</Text>
              <TextInput
                style={styles.input}
                value={cReason}
                onChangeText={setCReason}
                placeholder="مثال: خطأ في الإدخال"
                placeholderTextColor={Colors.textMuted}
              />

              {cError !== '' && <Text style={styles.errorText}>{cError}</Text>}

              <Pressable
                onPress={submitCorrection}
                disabled={cSaving}
                style={({ pressed }) => [styles.saveBtn, (pressed || cSaving) && { opacity: 0.8 }]}
              >
                {cSaving ? (
                  <ActivityIndicator color={Colors.textOnPrimary} />
                ) : (
                  <Text style={styles.saveBtnText}>حفظ التصحيح</Text>
                )}
              </Pressable>
              <Pressable onPress={closeCorrection} style={styles.cancelBtn}>
                <Text style={styles.cancelBtnText}>إلغاء</Text>
              </Pressable>
            </ScrollView>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: ROW, alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg, paddingTop: Spacing.lg, paddingBottom: Spacing.md,
  },
  headerTitle: { fontFamily: Fonts.extraBold, fontSize: FontSizes.xxl, color: Colors.textPrimary },
  headerSub: { fontFamily: Fonts.regular, fontSize: FontSizes.sm, color: Colors.textSecondary },
  addBtn: {
    width: 46, height: 46, borderRadius: Radius.full, backgroundColor: Colors.primary,
    alignItems: 'center', justifyContent: 'center', ...Shadows.primary,
  },
  searchBox: {
    flexDirection: ROW, alignItems: 'center', gap: Spacing.sm,
    marginHorizontal: Spacing.lg, marginBottom: Spacing.md, paddingHorizontal: Spacing.md,
    backgroundColor: Colors.card, borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.border,
  },
  searchInput: {
    flex: 1, height: 46, color: Colors.textPrimary, fontFamily: Fonts.regular, fontSize: FontSizes.md,
  },
  listContent: { paddingHorizontal: Spacing.lg, paddingBottom: Spacing.xxxl, gap: Spacing.md },
  card: {
    backgroundColor: Colors.card, borderRadius: Radius.lg, borderWidth: 1,
    borderColor: Colors.border, padding: Spacing.lg, gap: Spacing.sm, ...Shadows.card,
  },
  cardTop: {
    flexDirection: ROW, alignItems: 'flex-start', justifyContent: 'space-between',
    gap: Spacing.sm, marginBottom: Spacing.xs,
  },
  name: { flex: 1, fontFamily: Fonts.bold, fontSize: FontSizes.lg, color: Colors.textPrimary },
  badge: { paddingHorizontal: Spacing.md, paddingVertical: 2, borderRadius: Radius.full, borderWidth: 1 },
  badgeText: { fontFamily: Fonts.semiBold, fontSize: FontSizes.xs },
  infoRow: { flexDirection: ROW, justifyContent: 'space-between', alignItems: 'center', gap: Spacing.md },
  infoLabel: { fontFamily: Fonts.regular, fontSize: FontSizes.sm, color: Colors.textSecondary },
  infoValue: { flexShrink: 1, fontFamily: Fonts.medium, fontSize: FontSizes.sm, color: Colors.textPrimary },
  empty: { alignItems: 'center', gap: Spacing.md, marginTop: Spacing.xxxl },
  emptyText: { fontFamily: Fonts.medium, fontSize: FontSizes.md, color: Colors.textSecondary },
  overlay: { flex: 1, backgroundColor: Colors.overlay, justifyContent: 'flex-end' },
  sheet: {
    backgroundColor: Colors.card, borderTopLeftRadius: Radius.xl, borderTopRightRadius: Radius.xl,
    maxHeight: '92%', borderWidth: 1, borderColor: Colors.border,
  },
  sheetHeader: {
    flexDirection: ROW, alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg, paddingTop: Spacing.lg,
  },
  sheetTitle: { fontFamily: Fonts.bold, fontSize: FontSizes.lg, color: Colors.textPrimary },
  closeBtn: {
    width: 36, height: 36, borderRadius: Radius.full, backgroundColor: Colors.secondary,
    alignItems: 'center', justifyContent: 'center',
  },
  label: {
    fontFamily: Fonts.medium, fontSize: FontSizes.sm, color: Colors.textSecondary,
    marginTop: Spacing.md, marginBottom: Spacing.xs,
  },
  input: {
    height: 48, backgroundColor: Colors.secondary, borderRadius: Radius.md, borderWidth: 1,
    borderColor: Colors.border, paddingHorizontal: Spacing.md, color: Colors.textPrimary,
    fontFamily: Fonts.regular, fontSize: FontSizes.md,
  },
  selector: {
    height: 48, flexDirection: ROW, alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: Colors.secondary, borderRadius: Radius.md, borderWidth: 1,
    borderColor: Colors.border, paddingHorizontal: Spacing.md,
  },
  selectorText: { flex: 1, fontFamily: Fonts.regular, fontSize: FontSizes.md, color: Colors.textPrimary },
  dateRow: { flexDirection: ROW, gap: Spacing.sm },
  dateInput: { flex: 1, textAlign: 'center' },
  errorText: {
    fontFamily: Fonts.medium, fontSize: FontSizes.sm, color: Colors.danger, marginTop: Spacing.md,
  },
  saveBtn: {
    height: 50, borderRadius: Radius.md, backgroundColor: Colors.primary,
    alignItems: 'center', justifyContent: 'center', marginTop: Spacing.xl,
  },
  saveBtnText: { fontFamily: Fonts.bold, fontSize: FontSizes.md, color: Colors.textOnPrimary },
  cancelBtn: { height: 46, alignItems: 'center', justifyContent: 'center', marginTop: Spacing.sm },
  cancelBtnText: { fontFamily: Fonts.medium, fontSize: FontSizes.md, color: Colors.textSecondary },
  pickerOverlay: {
    flex: 1, backgroundColor: Colors.overlay, justifyContent: 'center', padding: Spacing.xl,
  },
  pickerCard: {
    backgroundColor: Colors.card, borderRadius: Radius.lg, borderWidth: 1,
    borderColor: Colors.border, padding: Spacing.lg, maxHeight: '75%',
  },
  pickerItem: {
    flexDirection: ROW, alignItems: 'center', justifyContent: 'space-between',
    paddingVertical: Spacing.md, borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  pickerItemText: { flex: 1, fontFamily: Fonts.regular, fontSize: FontSizes.md, color: Colors.textPrimary },
  moveCard: {
    backgroundColor: Colors.secondary, borderRadius: Radius.md, borderWidth: 1,
    borderColor: Colors.border, padding: Spacing.md, gap: Spacing.xs,
  },
  moveDate: { fontFamily: Fonts.medium, fontSize: FontSizes.sm, color: Colors.textSecondary },
  sectionTitle: {
    fontFamily: Fonts.bold, fontSize: FontSizes.md, color: Colors.textPrimary,
    marginTop: Spacing.lg, marginBottom: Spacing.xs,
  },
  actionsRow: { flexDirection: ROW, gap: Spacing.md, marginTop: Spacing.md },
  actionBtn: {
    flex: 1, height: 46, borderRadius: Radius.md, flexDirection: ROW,
    alignItems: 'center', justifyContent: 'center', gap: Spacing.sm,
  },
  actionBtnText: { fontFamily: Fonts.bold, fontSize: FontSizes.md, color: Colors.textOnPrimary },
  corrBtn: {
    height: 44, borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.warning,
    backgroundColor: Colors.warning + '22', flexDirection: ROW, alignItems: 'center',
    justifyContent: 'center', gap: Spacing.sm, marginTop: Spacing.sm,
  },
  corrBtnText: { fontFamily: Fonts.bold, fontSize: FontSizes.md, color: Colors.warning },
  corrCard: {
    backgroundColor: Colors.secondary, borderRadius: Radius.md, borderWidth: 1,
    borderColor: Colors.border, padding: Spacing.md, gap: Spacing.xs,
  },
  noteText: {
    fontFamily: Fonts.regular, fontSize: FontSizes.sm, color: Colors.textSecondary,
    marginBottom: Spacing.sm,
  },
  chipsRow: { flexDirection: ROW, gap: Spacing.sm, marginBottom: Spacing.sm },
  chip: {
    flex: 1, height: 42, borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.border,
    backgroundColor: Colors.secondary, alignItems: 'center', justifyContent: 'center',
  },
  chipText: { fontFamily: Fonts.medium, fontSize: FontSizes.sm, color: Colors.textSecondary },
});
