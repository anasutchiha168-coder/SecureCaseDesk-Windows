import React, { useState } from 'react';
import { View, Text, ScrollView, StyleSheet, Pressable, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { runProtectionTest } from '@/security/protection-test';
import { runAuditProtectionTest } from '@/security/audit-protection-test';
import { LogOut, FileText, Sparkles, Search, ListChecks, ShieldCheck } from 'lucide-react-native'; // SECURECASEDESK_PHASE11_S1
import { router } from 'expo-router'; // SECURECASEDESK_PHASE9_S3
import { useAuth } from '@/context/AuthContext';
import { inspectDatabaseEncryption } from '@/database/db';
import { Colors } from '@/constants/theme';
import { roleLabel, can } from '@/security/permissions';

function InfoLine({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.line}>
      <Text style={styles.lineLabel}>{label}</Text>
      <Text style={styles.lineValue}>{value}</Text>
    </View>
  );
}

export default function SettingsScreen() {
  const { user, logout } = useAuth();
  const [testing, setTesting] = useState(false);
  const [encryptionTesting, setEncryptionTesting] = useState(false);
  const [auditTesting, setAuditTesting] = useState(false);

  const runTest = async () => {
    if (testing || !user) return;
    setTesting(true);
    try {
      const report = await runProtectionTest(user.id);
      Alert.alert('نتيجة فحص الحماية', report);
    } catch (e) {
      console.error('[ProtectionTest] error:', e);
      Alert.alert('خطأ', 'تعذر تنفيذ الفحص');
    } finally {
      setTesting(false);
    }
  };

const runEncryptionTest = async () => {
    if (encryptionTesting) return;

    setEncryptionTesting(true);

    try {
      const result = await inspectDatabaseEncryption();

      const lines = [
        'إصدار SQLCipher: ' + result.cipherVersion,
        'حجم ملف القاعدة: ' + result.fileSize + ' بايت',
        'قراءة بنية القاعدة بالمفتاح الحالي: ناجحة',
      ];

      if (!result.headerReadable) {
        lines.push(
          'تعذر قراءة التوقيع كاملاً. لا يمكن إصدار نتيجة عن رأس الملف.'
        );
      } else if (result.sqliteHeaderDetected) {
        lines.push(
          'تحذير: ظهر توقيع SQLite العادي. الملف الذي فُحص لا يظهر كرأس قاعدة SQLCipher مشفرة.'
        );
      } else {
        lines.push(
          'لم يظهر توقيع SQLite العادي. النتيجة متوافقة مع وجود التشفير، لكنها مؤشر أولي وليست إثباتاً نهائياً مستقلاً.'
        );
      }

      Alert.alert('نتيجة فحص تشفير قاعدة البيانات', lines.join('\n'));
    } catch (e) {
      Alert.alert(
        'تعذر فحص التشفير',
        'لم يكتمل الفحص. تحقق من توفر SQLCipher وإمكانية قراءة ملف قاعدة البيانات.'
      );
    } finally {
      setEncryptionTesting(false);
    }
  };

  const runAuditTest = async () => {
    if (auditTesting || !user) return;
    setAuditTesting(true);
    try {
      const report = await runAuditProtectionTest(user.id);
      Alert.alert('نتيجة فحص سجل التدقيق', report);
    } catch (e) {
      console.error('[AuditProtectionTest] error:', e);
      Alert.alert('خطأ', 'تعذر تنفيذ فحص سجل التدقيق');
    } finally {
      setAuditTesting(false);
    }
  };

  const confirmLogout = () => {
    Alert.alert('تسجيل الخروج', 'هل تريد تسجيل الخروج من الحساب؟', [
      { text: 'إلغاء', style: 'cancel' },
      {
        text: 'تسجيل الخروج',
        style: 'destructive',
        onPress: async () => {
          await logout();
        },
      },
    ]);
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <Text style={styles.title}>الإعدادات</Text>

        <Text style={styles.sectionTitle}>الحساب</Text>
        <View style={styles.card}>
          <InfoLine label="اسم المستخدم" value={user?.username ?? '—'} />
          <InfoLine label="الدور" value={roleLabel(user?.role)} />
          <InfoLine label="الجهة" value="وزارة الداخلية - إدارة المباحث الجنائية - م/ حجة" />
        </View>

        {can(user?.role, 'ai.use') && ( // SECURECASEDESK_PHASE11_S2
          <Pressable
            onPress={() => router.push('/ai-search' as never)}
            style={({ pressed }) => [{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, height: 48, borderRadius: 12, borderWidth: 1, borderColor: Colors.primary, backgroundColor: Colors.card, marginBottom: 12 }, pressed && { opacity: 0.85 }]}
          >
            <Search color={Colors.primary} size={20} />
            <Text style={{ color: Colors.primary, fontFamily: 'Cairo_700Bold', fontSize: 15 }}>البحث الذكي</Text>
          </Pressable>
        )}

        {can(user?.role, 'ai.use') && ( // SECURECASEDESK_PHASE11_S3
          <Pressable
            onPress={() => router.push('/ai-summary' as never)}
            style={({ pressed }) => [{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, height: 48, borderRadius: 12, borderWidth: 1, borderColor: Colors.primary, backgroundColor: Colors.card, marginBottom: 12 }, pressed && { opacity: 0.85 }]}
          >
            <ListChecks color={Colors.primary} size={20} />
            <Text style={{ color: Colors.primary, fontFamily: 'Cairo_700Bold', fontSize: 15 }}>التلخيص الذكي</Text>
          </Pressable>
        )}

        {can(user?.role, 'ai.use') && can(user?.role, 'memos.view') && ( // SECURECASEDESK_PHASE11_S4
          <Pressable
            onPress={() => router.push('/ai-drafting' as never)}
            style={({ pressed }) => [{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, height: 48, borderRadius: 12, borderWidth: 1, borderColor: Colors.primary, backgroundColor: Colors.card, marginBottom: 12 }, pressed && { opacity: 0.85 }]}
          >
            <FileText color={Colors.primary} size={20} />
            <Text style={{ color: Colors.primary, fontFamily: 'Cairo_700Bold', fontSize: 15 }}>المساعد في صياغة المستندات</Text>
          </Pressable>
        )}

        {can(user?.role, 'ai.manage') && (
          <Pressable
            onPress={() => router.push('/ai-settings' as never)}
            style={({ pressed }) => [{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, height: 48, borderRadius: 12, borderWidth: 1, borderColor: Colors.primary, backgroundColor: Colors.card, marginBottom: 12 }, pressed && { opacity: 0.85 }]}
          >
            <Sparkles color={Colors.primary} size={20} />
            <Text style={{ color: Colors.primary, fontFamily: 'Cairo_700Bold', fontSize: 15 }}>إعدادات الذكاء الاصطناعي</Text>
          </Pressable>
        )}

        {can(user?.role, 'ai.manage') && ( // SECURECASEDESK_PHASE11_S5
          <Pressable
            onPress={() => router.push('/ai-privacy' as never)}
            style={({ pressed }) => [{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, height: 48, borderRadius: 12, borderWidth: 1, borderColor: Colors.primary, backgroundColor: Colors.card, marginBottom: 12 }, pressed && { opacity: 0.85 }]}
          >
            <ShieldCheck color={Colors.primary} size={20} />
            <Text style={{ color: Colors.primary, fontFamily: 'Cairo_700Bold', fontSize: 15 }}>فحص خصوصية الذكاء الاصطناعي</Text>
          </Pressable>
        )}

        {can(user?.role, 'audit.verify') && ( // SECURECASEDESK_PHASE12_S2
          <Pressable
            onPress={() => router.push('/security-check' as never)}
            style={({ pressed }) => [{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, height: 48, borderRadius: 12, borderWidth: 1, borderColor: Colors.primary, backgroundColor: Colors.card, marginBottom: 12 }, pressed && { opacity: 0.85 }]}
          >
            <ShieldCheck color={Colors.primary} size={20} />
            <Text style={{ color: Colors.primary, fontFamily: 'Cairo_700Bold', fontSize: 15 }}>فحص الأمان على الجهاز</Text>
          </Pressable>
        )}

        {can(user?.role, 'dashboard.view') && (
          <Pressable
            onPress={() => router.push('/reports' as never)}
            style={({ pressed }) => [{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, height: 48, borderRadius: 12, borderWidth: 1, borderColor: Colors.primary, backgroundColor: Colors.card, marginBottom: 12 }, pressed && { opacity: 0.85 }]}
          >
            <FileText color={Colors.primary} size={20} />
            <Text style={{ color: Colors.primary, fontFamily: 'Cairo_700Bold', fontSize: 15 }}>التقارير والمستندات</Text>
          </Pressable>
        )}

        <Pressable
          onPress={confirmLogout}
          style={({ pressed }) => [styles.logoutBtn, pressed && { opacity: 0.85 }]}
        >
          <LogOut color={Colors.danger} size={20} />
          <Text style={styles.logoutText}>تسجيل الخروج</Text>
        </Pressable>
      {can(user?.role, 'users.manage') && (
          <View style={{ marginTop: 28 }}>
            <Text style={styles.sectionTitle}>أدوات الفحص (مؤقتة)</Text>
            <Pressable
              onPress={runEncryptionTest}
              disabled={encryptionTesting}
              style={({ pressed }) => [
                styles.testBtn,
                (pressed || encryptionTesting) && { opacity: 0.7 }
              ]}
            >
              <Text style={styles.testText}>
                {encryptionTesting
                  ? 'جارٍ فحص تشفير القاعدة...'
                  : 'فحص تشفير قاعدة البيانات'}
              </Text>
            </Pressable>

<Pressable
              onPress={runTest}
              disabled={testing}
              style={({ pressed }) => [styles.testBtn, (pressed || testing) && { opacity: 0.7 }]}
            >
              <Text style={styles.testText}>{testing ? 'جارٍ الفحص...' : 'فحص حماية السجلات'}</Text>
            </Pressable>

            <Pressable
              onPress={runAuditTest}
              disabled={auditTesting}
              style={({ pressed }) => [styles.testBtn, (pressed || auditTesting) && { opacity: 0.7 }]}
            >
              <Text style={styles.testText}>
                {auditTesting ? 'جارٍ فحص سجل التدقيق...' : 'فحص إنشاء وحماية سجل التدقيق'}
              </Text>
            </Pressable>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  scroll: { paddingHorizontal: 20, paddingBottom: 40, paddingTop: 16 },
  title: { color: Colors.textPrimary, fontFamily: 'Cairo_700Bold', fontSize: 22, marginBottom: 20, textAlign: 'right' },
  sectionTitle: { color: Colors.textPrimary, fontFamily: 'Cairo_700Bold', fontSize: 16, marginBottom: 12, textAlign: 'right' },
  card: { backgroundColor: Colors.card, borderRadius: 16, borderWidth: 1, borderColor: Colors.border, padding: 16, gap: 12, marginBottom: 24 },
  line: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 },
  lineLabel: { color: Colors.textMuted, fontFamily: 'Cairo_400Regular', fontSize: 13 },
  lineValue: { flex: 1, color: Colors.textPrimary, fontFamily: 'Cairo_600SemiBold', fontSize: 14, textAlign: 'left' },
  logoutBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, height: 48, borderRadius: 12, borderWidth: 1, borderColor: Colors.danger, backgroundColor: Colors.card },
  logoutText: { color: Colors.danger, fontFamily: 'Cairo_700Bold', fontSize: 15 },
  testBtn: { height: 48, borderRadius: 12, borderWidth: 1, borderColor: Colors.warning, backgroundColor: Colors.card, alignItems: 'center', justifyContent: 'center' },
  testText: { color: Colors.warning, fontFamily: 'Cairo_700Bold', fontSize: 15 },
});
