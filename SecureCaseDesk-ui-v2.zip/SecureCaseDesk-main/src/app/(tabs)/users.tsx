import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, Pressable, Modal, TextInput,
  Alert, ActivityIndicator, ScrollView, KeyboardAvoidingView, Platform, I18nManager,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Plus, X } from 'lucide-react-native';
import * as Crypto from 'expo-crypto';
import { getDb } from '@/database/db';
import { useAuth } from '@/context/AuthContext';
import { can, assertUserCan, ROLES, roleLabel, normalizeRole } from '@/security/permissions';
import type { Role } from '@/security/permissions';
import { Colors, Spacing, Radius, Fonts, FontSizes } from '@/constants/theme';

const ROW = I18nManager.isRTL ? 'row' : 'row-reverse';

interface UserRow {
  id: string;
  username: string;
  role: string;
  created_at: number | string;
  department_id: string | null;
  department_name: string | null;
  is_active: number;
  last_login: number | null;
}
interface DepartmentRow { id: string; name: string; }

function roleColor(role: string): string {
  const r = normalizeRole(role);
  if (r === 'admin') return Colors.primaryLight;
  if (r === 'investigator') return Colors.success;
  if (r === 'detention_viewer') return Colors.warning;
  return Colors.textSecondary;
}

export default function UsersScreen() {
  const { user } = useAuth();
  const isAdmin = can(user?.role, 'users.manage');

  const [users, setUsers] = useState<UserRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [role, setRole] = useState<Role | null>(null);
  const [departments, setDepartments] = useState<DepartmentRow[]>([]);
  const [departmentId, setDepartmentId] = useState<string | null>(null);
  const [showEdit, setShowEdit] = useState(false);
  const [editingUser, setEditingUser] = useState<UserRow | null>(null);
  const [editRole, setEditRole] = useState<Role | null>(null);
  const [editDepartmentId, setEditDepartmentId] = useState<string | null>(null);
  const [busyUserId, setBusyUserId] = useState<string | null>(null);

  const loadUsers = useCallback(async () => {
    if (!isAdmin) {
      setLoading(false);
      return;
    }
    try {
      const db = await getDb();
      const [rows, departmentRows] = await Promise.all([
        db.getAllAsync<UserRow>(
          `SELECT u.id, u.username, u.role, u.created_at, u.department_id,
                  d.name AS department_name,
                  COALESCE(u.is_active, 1) AS is_active,
                  u.last_login
           FROM users u
           LEFT JOIN departments d ON d.id = u.department_id
           ORDER BY u.created_at ASC, u.rowid ASC`
        ),
        db.getAllAsync<DepartmentRow>(
          'SELECT id, name FROM departments WHERE is_active = 1 ORDER BY name ASC'
        ),
      ]);

      setUsers(rows);
      setDepartments(departmentRows);
    } catch (e) {
      console.error('[Users] load error:', e);
      Alert.alert('خطأ', 'تعذر تحميل قائمة المستخدمين');
    } finally {
      setLoading(false);
    }
  }, [isAdmin]);

  useEffect(() => {
    loadUsers();
  }, [loadUsers]);

  const openAdd = () => {
    setUsername('');
    setPassword('');
    setConfirm('');
    setRole(null);
    setDepartmentId(null);
    setError('');
    setShowAdd(true);
  };

  const closeAdd = () => {
    if (saving) return;
    setShowAdd(false);
  };

  const persist = async (name: string, pass: string, newRole: Role, newDepartmentId: string | null) => {
    if (!user) return;
    const actorId = user.id;
    setSaving(true);
    setError('');
    try {
      const hash = await Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, pass);
      const db = await getDb();
      await db.withTransactionAsync(async () => {
        await assertUserCan(db, actorId, 'users.manage');
        const dup = await db.getFirstAsync<{ id: string }>(
          'SELECT id FROM users WHERE LOWER(username) = LOWER(?)',
          [name]
        );
        if (dup) throw new Error('DUPLICATE');

        if (newDepartmentId) {
          const dept = await db.getFirstAsync<{ id: string }>(
            'SELECT id FROM departments WHERE id = ? AND is_active = 1',
            [newDepartmentId]
          );
          if (!dept) throw new Error('INVALID_DEPARTMENT');
        }

        await db.runAsync(
          `INSERT INTO users
           (id, username, password_hash, role, created_at, department_id, is_active)
           VALUES (?, ?, ?, ?, ?, ?, 1)`,
          [Crypto.randomUUID(), name, hash, newRole, Date.now(), newDepartmentId]
        );
      });
      setShowAdd(false);
      await loadUsers();
      Alert.alert('تم الحفظ', 'تم إنشاء الحساب بنجاح');
    } catch (e) {
      console.error('[Users] create error:', e);
      const msg = String((e as Error)?.message ?? '');
      if (msg.includes('FORBIDDEN')) {
        setError('إنشاء المستخدمين من صلاحيات المدير فقط');
      } else if (msg.includes('DUPLICATE') || msg.includes('UNIQUE')) {
        setError('اسم المستخدم مستخدم مسبقاً');
      } else if (msg.includes('INVALID_DEPARTMENT')) {
        setError('القسم المحدد غير موجود أو غير نشط');
      } else {
        setError('تعذر الحفظ ولم يتم إنشاء أي حساب، حاول مرة أخرى');
      }
    } finally {
      setSaving(false);
    }
  };

  const openEdit = (item: UserRow) => {
    setEditingUser(item);
    setEditRole(normalizeRole(item.role));
    setEditDepartmentId(item.department_id);
    setShowEdit(true);
  };

  const saveEdit = async () => {
    if (!user || !editingUser || !editRole) return;

    try {
      const db = await getDb();

      await db.withTransactionAsync(async () => {
        await assertUserCan(db, user.id, 'users.manage');

        const target = await db.getFirstAsync<{ role: string; is_active: number }>(
          'SELECT role, COALESCE(is_active, 1) AS is_active FROM users WHERE id = ?',
          [editingUser.id]
        );

        if (!target) throw new Error('USER_NOT_FOUND');
        if (editingUser.id === user.id && editRole !== 'admin') {
          throw new Error('SELF_ROLE_CHANGE');
        }

        if (editDepartmentId) {
          const dept = await db.getFirstAsync<{ id: string }>(
            'SELECT id FROM departments WHERE id = ? AND is_active = 1',
            [editDepartmentId]
          );
          if (!dept) throw new Error('INVALID_DEPARTMENT');
        }

        if (
          normalizeRole(target.role) === 'admin' &&
          Number(target.is_active) === 1 &&
          editRole !== 'admin'
        ) {
          const count = await db.getFirstAsync<{ count: number }>(
            `SELECT COUNT(*) AS count FROM users
             WHERE LOWER(role) = 'admin' AND COALESCE(is_active, 1) = 1`
          );
          if ((count?.count ?? 0) <= 1) throw new Error('LAST_ADMIN');
        }

        await db.runAsync(
          'UPDATE users SET role = ?, department_id = ? WHERE id = ?',
          [editRole, editDepartmentId, editingUser.id]
        );
      });

      setShowEdit(false);
      setEditingUser(null);
      await loadUsers();
      Alert.alert('تم التحديث', 'تم حفظ تعديلات حساب المستخدم');

    } catch (e) {
      const msg = String((e as Error)?.message ?? '');

      if (msg.includes('FORBIDDEN')) {
        Alert.alert('رفض العملية', 'إدارة الحسابات من صلاحيات المدير النشط فقط');
      } else if (msg.includes('LAST_ADMIN')) {
        Alert.alert('تعذر التعديل', 'لا يمكن تغيير دور آخر مدير نشط');
      } else if (msg.includes('SELF_ROLE_CHANGE')) {
        Alert.alert('تعذر التعديل', 'لا يمكنك تغيير دور حسابك الحالي');
      } else if (msg.includes('INVALID_DEPARTMENT')) {
        Alert.alert('خطأ', 'القسم المحدد غير موجود أو غير نشط');
      } else {
        Alert.alert('خطأ', 'تعذر تعديل الحساب');
      }
    }
  };

  const toggleUserStatus = (item: UserRow) => {
    const next = Number(item.is_active) === 1 ? 0 : 1;

    if (item.id === user?.id && next === 0) {
      Alert.alert('تعذر التعطيل', 'لا يمكنك تعطيل الحساب المستخدم حالياً');
      return;
    }

    Alert.alert(
      next ? 'تأكيد التفعيل' : 'تأكيد التعطيل',
      next
        ? 'هل تريد تفعيل حساب «' + item.username + '»؟'
        : 'سيُمنع الحساب من تسجيل الدخول. هل تريد المتابعة؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'تأكيد',
          style: next ? 'default' : 'destructive',
          onPress: () => { void persistUserStatus(item, next); }
        }
      ]
    );
  };

  const persistUserStatus = async (item: UserRow, next: number) => {
    if (!user) return;

    setBusyUserId(item.id);

    try {
      const db = await getDb();

      await db.withTransactionAsync(async () => {
        await assertUserCan(db, user.id, 'users.manage');

        const target = await db.getFirstAsync<{ role: string; is_active: number }>(
          'SELECT role, COALESCE(is_active, 1) AS is_active FROM users WHERE id = ?',
          [item.id]
        );

        if (!target) throw new Error('USER_NOT_FOUND');

        if (
          next === 0 &&
          normalizeRole(target.role) === 'admin' &&
          Number(target.is_active) === 1
        ) {
          const count = await db.getFirstAsync<{ count: number }>(
            `SELECT COUNT(*) AS count FROM users
             WHERE LOWER(role) = 'admin' AND COALESCE(is_active, 1) = 1`
          );

          if ((count?.count ?? 0) <= 1) throw new Error('LAST_ADMIN');
        }

        await db.runAsync(
          'UPDATE users SET is_active = ? WHERE id = ?',
          [next, item.id]
        );
      });

      await loadUsers();
      Alert.alert('تم التحديث', next ? 'تم تفعيل الحساب' : 'تم تعطيل الحساب');

    } catch (e) {
      const msg = String((e as Error)?.message ?? '');

      if (msg.includes('FORBIDDEN')) {
        Alert.alert('رفض العملية', 'يجب أن يكون حساب المدير نشطاً');
      } else if (msg.includes('LAST_ADMIN')) {
        Alert.alert('تعذر التعطيل', 'لا يمكن تعطيل آخر مدير نشط');
      } else {
        Alert.alert('خطأ', 'تعذر تغيير حالة الحساب');
      }
    } finally {
      setBusyUserId(null);
    }
  };

  const submit = () => {
    if (saving) return;
    if (!user || !can(user.role, 'users.manage')) {
      setError('إنشاء المستخدمين من صلاحيات المدير فقط');
      return;
    }
    const name = username.trim();
    if (name.length < 3) {
      setError('اسم المستخدم يجب ألا يقل عن 3 أحرف');
      return;
    }
    if (name.includes(' ')) {
      setError('اسم المستخدم لا يجوز أن يحتوي مسافات');
      return;
    }
    if (password.length < 8) {
      setError('كلمة المرور يجب ألا تقل عن 8 أحرف');
      return;
    }
    if (password !== confirm) {
      setError('كلمتا المرور غير متطابقتين');
      return;
    }
    if (!role) {
      setError('اختر دور المستخدم');
      return;
    }
    setError('');
    const chosen = role;
    const pass = password;
    Alert.alert(
      'تأكيد إنشاء الحساب',
      'سيتم إنشاء الحساب «' + name + '» بدور «' + roleLabel(chosen) + '». هل تريد المتابعة؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        { text: 'تأكيد', onPress: () => persist(name, pass, chosen, departmentId) },
      ]
    );
  };

  const renderItem = ({ item }: { item: UserRow }) => {
    const color = roleColor(item.role);
    const active = Number(item.is_active) === 1;
    return (
      <View style={styles.card}>
        <Text style={styles.cardName} numberOfLines={1}>{item.username}</Text>
        <View style={[styles.badge, { backgroundColor: color + '22', borderColor: color }]}>
          <Text style={[styles.badgeText, { color }]}>{roleLabel(item.role)}</Text>
        </View>
        <Text style={styles.metaText}>القسم: {item.department_name || 'غير محدد'}</Text>
        <Text style={styles.metaText}>الحالة: {active ? 'نشط' : 'معطّل'}</Text>
        <Text style={styles.metaText}>
          آخر دخول: {item.last_login ? new Date(item.last_login).toLocaleString('ar-YE') : 'لم يسجل الدخول بعد'}
        </Text>
        <View style={styles.actionsRow}>
          <Pressable onPress={() => openEdit(item)} style={styles.actionBtn}>
            <Text style={styles.editActionText}>تعديل</Text>
          </Pressable>
          <Pressable onPress={() => toggleUserStatus(item)} disabled={busyUserId === item.id} style={styles.actionBtn}>
            {busyUserId === item.id
              ? <ActivityIndicator size="small" color={Colors.textPrimary} />
              : <Text style={[styles.statusActionText, { color: active ? Colors.danger : Colors.success }]}>
                  {active ? 'تعطيل الحساب' : 'تفعيل الحساب'}
                </Text>}
          </Pressable>
        </View>
      </View>
    );
  };

  const selectedRole = ROLES.find((r) => r.key === role);

  if (!isAdmin) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.centered}>
          <Text style={styles.emptyText}>هذه الشاشة للمدير فقط</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.title}>إدارة المستخدمين</Text>
        <Pressable
          onPress={openAdd}
          style={({ pressed }) => [styles.addBtn, pressed && { opacity: 0.85 }]}
        >
          <Plus size={18} color={Colors.textOnPrimary} />
          <Text style={styles.addBtnText}>إضافة مستخدم</Text>
        </Pressable>
      </View>

      {loading ? (
        <ActivityIndicator color={Colors.primary} style={{ marginTop: Spacing.xxl }} />
      ) : (
        <FlatList
          data={users}
          keyExtractor={(u) => u.id}
          renderItem={renderItem}
          contentContainerStyle={{ padding: Spacing.lg, gap: Spacing.sm }}
          ListEmptyComponent={<Text style={styles.emptyText}>لا يوجد مستخدمون</Text>}
        />
      )}

      <Modal visible={showAdd} transparent animationType="slide" statusBarTranslucent onRequestClose={closeAdd}>
        <KeyboardAvoidingView
          style={styles.overlay}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        >
          <View style={styles.sheet}>
            <View style={styles.sheetHeader}>
              <Text style={styles.sheetTitle}>إضافة مستخدم</Text>
              <Pressable onPress={closeAdd} style={styles.closeBtn}>
                <X size={20} color={Colors.textSecondary} />
              </Pressable>
            </View>

            <ScrollView
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={{ padding: Spacing.lg, paddingBottom: Spacing.xxl }}
            >
              <Text style={styles.label}>اسم المستخدم *</Text>
              <TextInput
                style={styles.input}
                value={username}
                onChangeText={setUsername}
                autoCapitalize="none"
                autoCorrect={false}
                placeholder="3 أحرف على الأقل"
                placeholderTextColor={Colors.textMuted}
              />

              <Text style={styles.label}>كلمة المرور *</Text>
              <TextInput
                style={styles.input}
                value={password}
                onChangeText={setPassword}
                secureTextEntry
                autoCapitalize="none"
                autoCorrect={false}
                placeholder="8 أحرف على الأقل"
                placeholderTextColor={Colors.textMuted}
              />

              <Text style={styles.label}>تأكيد كلمة المرور *</Text>
              <TextInput
                style={styles.input}
                value={confirm}
                onChangeText={setConfirm}
                secureTextEntry
                autoCapitalize="none"
                autoCorrect={false}
                placeholder="أعد كتابة كلمة المرور"
                placeholderTextColor={Colors.textMuted}
              />

              <Text style={styles.label}>الدور *</Text>
              <View style={styles.chipsRow}>
                {ROLES.map((r) => {
                  const active = r.key === role;
                  return (
                    <Pressable
                      key={r.key}
                      style={[
                        styles.chip,
                        active && { borderColor: Colors.primary, backgroundColor: Colors.primary + '22' },
                      ]}
                      onPress={() => setRole(r.key)}
                    >
                      <Text
                        style={[styles.chipText, active && { color: Colors.primaryLight, fontFamily: Fonts.bold }]}
                      >
                        {r.label}
                      </Text>
                    </Pressable>
                  );
                })}
              </View>
              {selectedRole ? <Text style={styles.hint}>{selectedRole.description}</Text> : null}

              <Text style={styles.label}>القسم</Text>
              <View style={styles.chipsRow}>
                <Pressable
                  style={[styles.chip, departmentId === null && styles.chipActive]}
                  onPress={() => setDepartmentId(null)}
                >
                  <Text style={[styles.chipText, departmentId === null && styles.chipTextActive]}>
                    بلا قسم
                  </Text>
                </Pressable>

                {departments.map((dept) => (
                  <Pressable
                    key={dept.id}
                    style={[styles.chip, departmentId === dept.id && styles.chipActive]}
                    onPress={() => setDepartmentId(dept.id)}
                  >
                    <Text style={[styles.chipText, departmentId === dept.id && styles.chipTextActive]}>
                      {dept.name}
                    </Text>
                  </Pressable>
                ))}
              </View>

              {error !== '' && <Text style={styles.errorText}>{error}</Text>}

              <Pressable
                onPress={submit}
                disabled={saving}
                style={({ pressed }) => [styles.saveBtn, (pressed || saving) && { opacity: 0.8 }]}
              >
                {saving ? (
                  <ActivityIndicator color={Colors.textOnPrimary} />
                ) : (
                  <Text style={styles.saveBtnText}>إنشاء الحساب</Text>
                )}
              </Pressable>
              <Pressable onPress={closeAdd} style={styles.cancelBtn}>
                <Text style={styles.cancelBtnText}>إلغاء</Text>
              </Pressable>
            </ScrollView>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      <Modal
        visible={showEdit}
        transparent
        animationType="slide"
        statusBarTranslucent
        onRequestClose={() => setShowEdit(false)}
      >
        <KeyboardAvoidingView
          style={styles.overlay}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        >
          <View style={styles.sheet}>
            <View style={styles.sheetHeader}>
              <Text style={styles.sheetTitle}>
                تعديل حساب: {editingUser?.username ?? ''}
              </Text>
              <Pressable onPress={() => setShowEdit(false)} style={styles.closeBtn}>
                <X size={20} color={Colors.textSecondary} />
              </Pressable>
            </View>

            <ScrollView
              contentContainerStyle={{ padding: Spacing.lg, paddingBottom: Spacing.xxl }}
              keyboardShouldPersistTaps="handled"
            >
              <Text style={styles.label}>الدور</Text>

              <View style={styles.chipsRow}>
                {ROLES.map((r) => {
                  const active = editRole === r.key;
                  const locked = editingUser?.id === user?.id && r.key !== 'admin';

                  return (
                    <Pressable
                      key={r.key}
                      disabled={locked}
                      style={[
                        styles.chip,
                        active && styles.chipActive,
                        locked && { opacity: 0.4 }
                      ]}
                      onPress={() => setEditRole(r.key)}
                    >
                      <Text style={[styles.chipText, active && styles.chipTextActive]}>
                        {r.label}
                      </Text>
                    </Pressable>
                  );
                })}
              </View>

              <Text style={styles.label}>القسم</Text>

              <View style={styles.chipsRow}>
                <Pressable
                  style={[styles.chip, editDepartmentId === null && styles.chipActive]}
                  onPress={() => setEditDepartmentId(null)}
                >
                  <Text style={[styles.chipText, editDepartmentId === null && styles.chipTextActive]}>
                    بلا قسم
                  </Text>
                </Pressable>

                {departments.map((dept) => (
                  <Pressable
                    key={dept.id}
                    style={[styles.chip, editDepartmentId === dept.id && styles.chipActive]}
                    onPress={() => setEditDepartmentId(dept.id)}
                  >
                    <Text style={[styles.chipText, editDepartmentId === dept.id && styles.chipTextActive]}>
                      {dept.name}
                    </Text>
                  </Pressable>
                ))}
              </View>

              <Pressable onPress={saveEdit} style={styles.saveBtn}>
                <Text style={styles.saveBtnText}>حفظ التعديلات</Text>
              </Pressable>

              <Pressable onPress={() => setShowEdit(false)} style={styles.cancelBtn}>
                <Text style={styles.cancelBtnText}>إلغاء</Text>
              </Pressable>
            </ScrollView>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: Spacing.xl },
  header: {
    flexDirection: ROW, alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg, paddingTop: Spacing.lg, paddingBottom: Spacing.sm,
  },
  title: { fontFamily: Fonts.bold, fontSize: FontSizes.xl, color: Colors.textPrimary },
  addBtn: {
    flexDirection: ROW, alignItems: 'center', gap: Spacing.xs, backgroundColor: Colors.primary,
    paddingHorizontal: Spacing.md, height: 40, borderRadius: Radius.md,
  },
  addBtnText: { fontFamily: Fonts.bold, fontSize: FontSizes.sm, color: Colors.textOnPrimary },
  card: {
    flexDirection: ROW, alignItems: 'center', justifyContent: 'space-between', gap: Spacing.md,
    backgroundColor: Colors.card, borderRadius: Radius.lg, borderWidth: 1,
    borderColor: Colors.border, padding: Spacing.lg,
  },
  cardName: { flex: 1, fontFamily: Fonts.bold, fontSize: FontSizes.md, color: Colors.textPrimary },
  badge: { borderRadius: Radius.full, borderWidth: 1, paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs },
  badgeText: { fontFamily: Fonts.medium, fontSize: FontSizes.xs },
  metaText: {
    fontFamily: Fonts.regular, fontSize: FontSizes.sm,
    color: Colors.textSecondary, textAlign: 'right', marginTop: 3
  },
  actionsRow: { flexDirection: ROW, gap: Spacing.sm, marginTop: Spacing.sm },
  actionBtn: {
    flex: 1, minHeight: 38, borderWidth: 1, borderColor: Colors.border,
    borderRadius: Radius.md, alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: Spacing.sm
  },
  editActionText: {
    color: Colors.primaryLight, fontFamily: Fonts.bold, fontSize: FontSizes.sm
  },
  statusActionText: { fontFamily: Fonts.bold, fontSize: FontSizes.sm },
  chipActive: {
    borderColor: Colors.primary, backgroundColor: Colors.primary + '22'
  },
  chipTextActive: {
    color: Colors.primaryLight, fontFamily: Fonts.bold
  },
  emptyText: {
    fontFamily: Fonts.medium, fontSize: FontSizes.md, color: Colors.textSecondary, textAlign: 'center',
  },
  overlay: { flex: 1, backgroundColor: Colors.overlay, justifyContent: 'flex-end' },
  sheet: {
    backgroundColor: Colors.card, borderTopLeftRadius: Radius.xl, borderTopRightRadius: Radius.xl,
    borderWidth: 1, borderColor: Colors.border, maxHeight: '92%',
  },
  sheetHeader: {
    flexDirection: ROW, alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg, paddingTop: Spacing.lg,
  },
  sheetTitle: { fontFamily: Fonts.bold, fontSize: FontSizes.lg, color: Colors.textPrimary },
  closeBtn: { padding: Spacing.sm },
  label: {
    fontFamily: Fonts.medium, fontSize: FontSizes.sm, color: Colors.textSecondary,
    marginTop: Spacing.md, marginBottom: Spacing.xs,
  },
  input: {
    backgroundColor: Colors.secondary, borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.border,
    paddingHorizontal: Spacing.md, height: 46, color: Colors.textPrimary,
    fontFamily: Fonts.regular, fontSize: FontSizes.md,
  },
  chipsRow: { flexDirection: ROW, flexWrap: 'wrap', gap: Spacing.sm },
  chip: {
    paddingHorizontal: Spacing.md, height: 40, borderRadius: Radius.md, borderWidth: 1,
    borderColor: Colors.border, backgroundColor: Colors.secondary, alignItems: 'center', justifyContent: 'center',
  },
  chipText: { fontFamily: Fonts.medium, fontSize: FontSizes.sm, color: Colors.textSecondary },
  hint: {
    fontFamily: Fonts.regular, fontSize: FontSizes.sm, color: Colors.textSecondary, marginTop: Spacing.sm,
  },
  errorText: {
    fontFamily: Fonts.medium, fontSize: FontSizes.sm, color: Colors.danger, marginTop: Spacing.md,
  },
  saveBtn: {
    height: 48, borderRadius: Radius.md, backgroundColor: Colors.primary,
    alignItems: 'center', justifyContent: 'center', marginTop: Spacing.xl,
  },
  saveBtnText: { fontFamily: Fonts.bold, fontSize: FontSizes.md, color: Colors.textOnPrimary },
  cancelBtn: { height: 44, alignItems: 'center', justifyContent: 'center', marginTop: Spacing.sm },
  cancelBtnText: { fontFamily: Fonts.medium, fontSize: FontSizes.md, color: Colors.textSecondary },
});
