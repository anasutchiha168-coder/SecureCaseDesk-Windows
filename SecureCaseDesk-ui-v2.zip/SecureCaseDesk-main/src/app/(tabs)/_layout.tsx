import React, { useEffect } from 'react';
import { Tabs, Redirect, useSegments, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Home, FolderOpen, Users, FileText, Settings, UserPlus, ShieldCheck } from 'lucide-react-native';
import { View } from 'react-native';
import { Colors, Palette, tint } from '@/constants/theme';
import { useAuth } from '@/context/AuthContext';
import { canAccessTab, firstAllowedTab } from '@/security/permissions';
import { recordUnauthorizedAccess } from '@/modules/audit/audit-integration'; // SECTION3

function TabIcon({ focused, children }: { focused: boolean; children: React.ReactNode }) {
  return (
    <View style={{
      width: 46, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center',
      backgroundColor: focused ? tint(Palette.cyan, 0.14) : 'transparent',
      borderWidth: 1, borderColor: focused ? tint(Palette.cyan, 0.4) : 'transparent',
      shadowColor: Palette.cyan, shadowOpacity: focused ? 0.45 : 0, shadowRadius: 10, shadowOffset: { width: 0, height: 0 }, elevation: focused ? 4 : 0,
    }}>{children}</View>
  );
}

export default function TabLayout() {
  const { user, isLoading } = useAuth();
  const router = useRouter();
  const segments = useSegments() as unknown as string[];
  const role = user?.role;
  const insets = useSafeAreaInsets();

  // بعد تسجيل الخروج: الانتقال إلى شاشة الدخول يتم من هنا، بعد أن تصل حالة الخروج إلى الواجهة.
  useEffect(() => {
    if (!isLoading && !user) router.replace('/');
  }, [user, isLoading]);
  const currentTab = segments[0] === '(tabs)' ? (segments[1] ?? 'index') : null;

  // SECTION3: كل محاولة فتح تبويب غير مسموح تُسجَّل في سجل التدقيق قبل التحويل.
  useEffect(() => {
    if (user && currentTab && !canAccessTab(role, currentTab)) {
      void recordUnauthorizedAccess({
        userId: user.id,
        username: user.username,
        role: user.role,
        resource: 'tab:' + currentTab,
        detail: 'محاولة فتح شاشة غير مسموحة',
      });
    }
  }, [user?.id, currentTab, role]);

  // حماية الدخول المباشر: أي تبويب غير مصرح به يُحوَّل إلى أول تبويب مسموح.
  if (user && currentTab && !canAccessTab(role, currentTab)) {
    const target = firstAllowedTab(role);
    return <Redirect href={(target === 'index' ? '/' : '/' + target) as never} />;
  }

  const show = (tab: string) => (canAccessTab(role, tab) ? undefined : null);

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: Palette.cyan,
        tabBarInactiveTintColor: Colors.textMuted,
        tabBarStyle: {
          backgroundColor: Palette.bg0,
          borderTopColor: Palette.glassBorder,
          borderTopWidth: 1,
          height: 74 + insets.bottom,
          paddingBottom: 10 + insets.bottom,
          paddingTop: 8,
          elevation: 12,
        },
        tabBarLabelStyle: {
          fontFamily: 'Cairo_600SemiBold',
          fontSize: 10.5,
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'الرئيسية',
          href: show('index'),
          tabBarIcon: ({ color, focused }) => <TabIcon focused={focused}><Home color={color} size={21} /></TabIcon>,
        }}
      />
      <Tabs.Screen
        name="cases"
        options={{
          title: 'القضايا',
          href: show('cases'),
          tabBarIcon: ({ color, focused }) => <TabIcon focused={focused}><FolderOpen color={color} size={21} /></TabIcon>,
        }}
      />
      <Tabs.Screen
        name="detainees"
        options={{
          title: 'المحتجزون',
          href: show('detainees'),
          tabBarIcon: ({ color, focused }) => <TabIcon focused={focused}><Users color={color} size={21} /></TabIcon>,
        }}
      />
      <Tabs.Screen
        name="memos"
        options={{
          title: 'المذكرات',
          href: show('memos'),
          tabBarIcon: ({ color, focused }) => <TabIcon focused={focused}><FileText color={color} size={21} /></TabIcon>,
        }}
      />
      <Tabs.Screen
        name="users"
        options={{
          title: 'المستخدمون',
          href: show('users'),
          tabBarIcon: ({ color, focused }) => <TabIcon focused={focused}><UserPlus color={color} size={21} /></TabIcon>,
        }}
      />
      <Tabs.Screen
        name="audit"
        options={{
          title: 'سجل التدقيق',
          href: show('audit'),
          tabBarIcon: ({ color, focused }) => <TabIcon focused={focused}><ShieldCheck color={color} size={21} /></TabIcon>,
        }}
      />
      <Tabs.Screen
        name="settings"
        options={{
          title: 'الإعدادات',
          href: show('settings'),
          tabBarIcon: ({ color, focused }) => <TabIcon focused={focused}><Settings color={color} size={21} /></TabIcon>,
        }}
      />
    </Tabs>
  );
}
