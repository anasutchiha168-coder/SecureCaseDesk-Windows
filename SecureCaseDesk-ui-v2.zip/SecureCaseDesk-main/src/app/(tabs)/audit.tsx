
// SECURECASEDESK_PHASE8
import React, { useCallback, useEffect, useState } from 'react';
import {
  View, Text, TextInput, FlatList, Pressable,
  StyleSheet, ActivityIndicator, Alert
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router'; // SECTION3
import { auditOperationLabel, auditEntityLabel } from '@/modules/audit/audit-labels';
import { RefreshCw, ShieldCheck, Search } from 'lucide-react-native';
import { useAuth } from '@/context/AuthContext';
import { Colors, Spacing, Radius, Fonts, FontSizes } from '@/constants/theme';
import {
  getAuditLogs, verifyAuditChain, flushAuditQueue,
  type AuditLogRow
} from '@/services/audit.service';

const PAGE_SIZE = 30;

function operationLabel(value: string): string {
  const names: Record<string, string> = {
    create: 'إنشاء',
    update: 'تعديل',
    delete: 'حذف',
    login: 'تسجيل دخول',
    logout: 'تسجيل خروج',
    session: 'جلسة',
    failed_login: 'محاولة دخول فاشلة',
    protection_test: 'فحص حماية ذاتي',
  };
  return names[value] ?? auditOperationLabel(value);
}

function entityLabel(value: string): string {
  const names: Record<string, string> = {
    users: 'المستخدمون',
    departments: 'الأقسام',
    cases: 'القضايا',
    memos: 'المذكرات',
    detainees: 'المحتجزون',
    detainee_movements: 'حركات المحتجزين',
    correction_history: 'سجل التصحيحات',
    session: 'جلسات الدخول',
    self_test: 'فحص ذاتي',
  };
  return names[value] ?? auditEntityLabel(value);
}

function readable(value: string | null): string {
  if (!value) return 'غير متوفر';
  try {
    return JSON.stringify(JSON.parse(value), null, 2);
  } catch {
    return value;
  }
}

function parseDate(value: string, end: boolean): number | null {
  if (!value.trim()) return null;

  if (!/^\d{4}-\d{2}-\d{2}$/.test(value.trim())) {
    throw new Error('اكتب التاريخ بصيغة السنة-الشهر-اليوم');
  }

  const d = new Date(
    value.trim() + (end ? 'T23:59:59.999' : 'T00:00:00')
  );

  if (Number.isNaN(d.getTime()) ||
      d.toISOString().slice(0, 10) !== value.trim()) {
    throw new Error('التاريخ المدخل غير صحيح');
  }

  return d.getTime();
}

export default function AuditScreen() {
  const { user } = useAuth();
  const router = useRouter();

  const [rows, setRows] = useState<AuditLogRow[]>([]);
  const [query, setQuery] = useState('');
  const [fromText, setFromText] = useState('');
  const [toText, setToText] = useState('');
  const [offset, setOffset] = useState(0);
  const [loading, setLoading] = useState(false);
  const [more, setMore] = useState(true);
  const [verifying, setVerifying] = useState(false);

  const load = useCallback(async (reset: boolean) => {
    if (!user) return;

    setLoading(true);

    try {
      await flushAuditQueue();

      const from = parseDate(fromText, false);
      const to = parseDate(toText, true);

      if (from !== null && to !== null && from > to) {
        throw new Error('تاريخ البداية أكبر من تاريخ النهاية');
      }

      const nextOffset = reset ? 0 : offset;

      const result = await getAuditLogs(user.id, {
        query,
        from,
        to,
        offset: nextOffset,
        limit: PAGE_SIZE,
      });

      setRows((previous) => reset ? result : [...previous, ...result]);
      setOffset(nextOffset + result.length);
      setMore(result.length === PAGE_SIZE);

    } catch (e) {
      Alert.alert(
        'تعذر تحميل السجل',
        String((e as Error)?.message ?? 'حدث خطأ غير متوقع')
      );
    } finally {
      setLoading(false);
    }
  }, [user?.id, query, fromText, toText, offset]);

  useEffect(() => {
    void load(true);
  }, [user?.id]);

  const verify = async () => {
    if (!user || verifying) return;

    setVerifying(true);

    try {
      const result = await verifyAuditChain(user.id);
      const test = result.selfTest;

      if (result.ok) {
        Alert.alert(
          'التحقق من سلامة السجل',
          'سجل التدقيق سليم.\n' +
          'عدد السجلات: ' + result.count +
          '\nاختبار HMAC: ناجح' +
          '\nاختبار التعديل: ناجح' +
          '\nاختبار الحذف والانقطاع: ناجح' +
          '\nاختبار الترتيب: ناجح'
        );
      } else {
        const messages: Record<string, string> = {
          SEQUENCE_GAP: 'تم اكتشاف سجل مفقود أو انقطاع في التسلسل.',
          BROKEN_LINK: 'تم اكتشاف انقطاع في رابط السجل السابق.',
          INVALID_HMAC: 'تم اكتشاف تغيير في محتويات أحد السجلات.',
          UNKNOWN_VERSION: 'إصدار التوقيع غير معروف.',
          SELF_TEST_FAILED: 'فشل الاختبار الداخلي لخوارزمية HMAC.',
        };

        Alert.alert(
          'تحذير أمني',
          (messages[result.code] ?? 'تعذر التحقق من سلامة السجل.') +
          (result.badSequence
            ? '\nرقم السجل المتأثر: ' + result.badSequence
            : '')
        );
      }
    } catch (e) {
      const message = String((e as Error)?.message ?? '');

      const translated =
        message.includes('AUDIT_KEY_MISSING') ||
        message.includes('AUDIT_KEY_NOT_INITIALIZED')
          ? 'مفتاح حماية سجل التدقيق غير متوفر. لم يتم إنشاء مفتاح بديل.'
          : message.includes('FORBIDDEN')
          ? 'عرض سجل التدقيق من صلاحيات المدير النشط فقط.'
          : 'تعذر إكمال التحقق. لم تُعلن سلامة السجل.';

      Alert.alert('تعذر التحقق', translated);
    } finally {
      setVerifying(false);
    }
  };

  const showDetails = (item: AuditLogRow) => {
    Alert.alert(
      'تفاصيل عملية التدقيق',
      'رقم العملية: ' + item.operation_id +
      '\nالمستخدم: ' + (item.username || 'النظام') +
      '\nالعملية: ' + operationLabel(item.operation_type) +
      '\nنوع السجل: ' + entityLabel(item.entity_type) +
      '\nمعرف السجل: ' + (item.entity_id || 'غير متوفر') +
      '\nالتاريخ: ' + new Date(item.created_at).toLocaleString('ar-YE') +
      '\n\nالقيم السابقة:\n' + readable(item.previous_values).slice(0, 700) +
      '\n\nالقيم الجديدة:\n' + readable(item.new_values).slice(0, 700) +
      '\n\nسبب التصحيح:\n' + (item.correction_reason || 'غير متوفر') +
      '\n\nإصدار الحماية: ' + item.hmac_version
    );
  };

  const renderItem = ({ item }: { item: AuditLogRow }) => (
    <Pressable
      style={styles.card}
      onPress={() => showDetails(item)}
    >
      <View style={styles.cardHeader}>
        <Text style={styles.operation}>
          {operationLabel(item.operation_type)}
        </Text>
        <Text style={styles.actor}>{item.username || 'النظام'}</Text>
      </View>

      <Text style={styles.entity}>
        {entityLabel(item.entity_type)}
        {item.entity_id ? ' — ' + item.entity_id : ''}
      </Text>

      <Text style={styles.date}>
        {new Date(item.created_at).toLocaleString('ar-YE')}
      </Text>

      <Text style={styles.sequence}>
        تسلسل السجل: {item.sequence_no}
      </Text>
    </Pressable>
  );

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.title}>سجل التدقيق</Text>
        <Pressable
          style={styles.iconBtn}
          onPress={() => void load(true)}
          disabled={loading}
        >
          <RefreshCw size={20} color={Colors.primaryLight} />
        </Pressable>
      </View>

      <View style={styles.info}>
        <ShieldCheck color={Colors.success} size={25} />
        <View style={{ flex: 1 }}>
          <Text style={styles.infoTitle}>سجل العمليات المحمي</Text>
          <Text style={styles.infoText}>
            سجلات متسلسلة محمية بتوقيعات HMAC-SHA256
          </Text>
        </View>
      </View>

      <Pressable
        style={styles.verifyButton}
        onPress={verify}
        disabled={verifying}
      >
        {verifying
          ? <ActivityIndicator color={Colors.textOnPrimary} />
          : <ShieldCheck color={Colors.textOnPrimary} size={20} />}
        <Text style={styles.verifyText}>
          {verifying ? 'جارٍ التحقق...' : 'التحقق من سلامة سلسلة السجلات'}
        </Text>
      </Pressable>

      <View style={{ marginHorizontal: Spacing.lg, marginBottom: Spacing.md, flexDirection: 'row-reverse', gap: Spacing.sm }}>
        <Pressable
          style={{ flex: 1, minHeight: 46, borderRadius: Radius.md, backgroundColor: Colors.secondary, borderWidth: 1, borderColor: Colors.border, alignItems: 'center', justifyContent: 'center' }}
          onPress={() => router.push('/audit-report' as never)}
        >
          <Text style={{ color: Colors.textPrimary, fontFamily: Fonts.semiBold, fontSize: FontSizes.sm }}>تقرير التحقق</Text>
        </Pressable>
        <Pressable
          style={{ flex: 1, minHeight: 46, borderRadius: Radius.md, backgroundColor: Colors.secondary, borderWidth: 1, borderColor: Colors.border, alignItems: 'center', justifyContent: 'center' }}
          onPress={() => router.push('/audit-sync' as never)}
        >
          <Text style={{ color: Colors.textPrimary, fontFamily: Fonts.semiBold, fontSize: FontSizes.sm }}>حالة المزامنة</Text>
        </Pressable>
      </View>

      <View style={styles.searchBox}>
        <Search color={Colors.textMuted} size={18} />
        <TextInput
          value={query}
          onChangeText={setQuery}
          placeholder="ابحث بالمستخدم أو العملية أو المعرف..."
          placeholderTextColor={Colors.textMuted}
          style={styles.searchInput}
          textAlign="right"
          onSubmitEditing={() => {
            setOffset(0);
            void load(true);
          }}
        />
      </View>

      <View style={styles.dateRow}>
        <TextInput
          value={fromText}
          onChangeText={setFromText}
          style={styles.dateInput}
          placeholder="من: YYYY-MM-DD"
          placeholderTextColor={Colors.textMuted}
          textAlign="center"
        />
        <TextInput
          value={toText}
          onChangeText={setToText}
          style={styles.dateInput}
          placeholder="إلى: YYYY-MM-DD"
          placeholderTextColor={Colors.textMuted}
          textAlign="center"
        />
      </View>

      <Pressable
        style={styles.filterButton}
        onPress={() => {
          setOffset(0);
          void load(true);
        }}
      >
        <Text style={styles.filterText}>تطبيق البحث والتصفية</Text>
      </Pressable>

      {loading && rows.length === 0 ? (
        <ActivityIndicator
          size="large"
          color={Colors.primary}
          style={{ marginTop: 40 }}
        />
      ) : (
        <FlatList
          data={rows}
          keyExtractor={(item) => item.operation_id}
          renderItem={renderItem}
          contentContainerStyle={styles.list}
          ListEmptyComponent={
            <Text style={styles.empty}>لا توجد عمليات تدقيق مسجلة.</Text>
          }
          ListFooterComponent={
            more ? (
              <Pressable
                style={styles.moreButton}
                onPress={() => void load(false)}
                disabled={loading}
              >
                <Text style={styles.filterText}>
                  {loading ? 'جارٍ التحميل...' : 'تحميل المزيد'}
                </Text>
              </Pressable>
            ) : undefined
          }
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    padding: Spacing.lg,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  title: {
    color: Colors.textPrimary,
    fontFamily: Fonts.bold,
    fontSize: FontSizes.xl,
  },
  iconBtn: {
    width: 42,
    height: 42,
    borderRadius: Radius.md,
    backgroundColor: Colors.secondary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  info: {
    marginHorizontal: Spacing.lg,
    padding: Spacing.md,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: Spacing.md,
    backgroundColor: Colors.card,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: Radius.lg,
  },
  infoTitle: {
    color: Colors.textPrimary,
    fontFamily: Fonts.bold,
    fontSize: FontSizes.md,
    textAlign: 'right',
  },
  infoText: {
    color: Colors.textSecondary,
    fontFamily: Fonts.regular,
    fontSize: FontSizes.xs,
    textAlign: 'right',
  },
  verifyButton: {
    margin: Spacing.lg,
    minHeight: 52,
    padding: Spacing.md,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    backgroundColor: Colors.primary,
    borderRadius: Radius.md,
  },
  verifyText: {
    color: Colors.textOnPrimary,
    fontFamily: Fonts.bold,
    fontSize: FontSizes.md,
  },
  searchBox: {
    marginHorizontal: Spacing.lg,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: Colors.card,
    borderColor: Colors.border,
    borderWidth: 1,
    borderRadius: Radius.md,
    paddingHorizontal: Spacing.md,
  },
  searchInput: {
    flex: 1,
    minHeight: 46,
    color: Colors.textPrimary,
    fontFamily: Fonts.regular,
    textAlign: 'right',
    marginRight: Spacing.sm,
  },
  dateRow: {
    flexDirection: 'row-reverse',
    gap: Spacing.sm,
    marginHorizontal: Spacing.lg,
    marginTop: Spacing.sm,
  },
  dateInput: {
    flex: 1,
    height: 42,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: Radius.md,
    backgroundColor: Colors.card,
    color: Colors.textPrimary,
    fontFamily: Fonts.regular,
    fontSize: FontSizes.xs,
  },
  filterButton: {
    marginHorizontal: Spacing.lg,
    marginTop: Spacing.sm,
    padding: Spacing.sm,
    borderRadius: Radius.md,
    backgroundColor: Colors.secondary,
    alignItems: 'center',
  },
  filterText: {
    color: Colors.primaryLight,
    fontFamily: Fonts.bold,
    fontSize: FontSizes.sm,
  },
  list: {
    padding: Spacing.lg,
    gap: Spacing.sm,
    paddingBottom: Spacing.xxl,
  },
  card: {
    padding: Spacing.md,
    backgroundColor: Colors.card,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: Radius.lg,
    gap: 5,
  },
  cardHeader: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  operation: {
    color: Colors.primaryLight,
    fontFamily: Fonts.bold,
    fontSize: FontSizes.md,
  },
  actor: {
    color: Colors.textPrimary,
    fontFamily: Fonts.semiBold,
    fontSize: FontSizes.sm,
  },
  entity: {
    color: Colors.textSecondary,
    fontFamily: Fonts.medium,
    fontSize: FontSizes.sm,
    textAlign: 'right',
  },
  date: {
    color: Colors.textMuted,
    fontFamily: Fonts.regular,
    fontSize: FontSizes.xs,
    textAlign: 'right',
  },
  sequence: {
    color: Colors.success,
    fontFamily: Fonts.medium,
    fontSize: FontSizes.xs,
    textAlign: 'right',
  },
  empty: {
    color: Colors.textMuted,
    fontFamily: Fonts.medium,
    textAlign: 'center',
    marginTop: Spacing.xxl,
  },
  moreButton: {
    backgroundColor: Colors.secondary,
    padding: Spacing.md,
    borderRadius: Radius.md,
    alignItems: 'center',
  },
});
