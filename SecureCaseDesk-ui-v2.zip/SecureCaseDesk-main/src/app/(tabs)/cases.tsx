// SECURECASEDESK_PHASE9_S2
import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Pressable,
  Modal,
  TextInput,
  Alert,
  ActivityIndicator,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Plus, X, FolderOpen, Search, ChevronDown, Check } from 'lucide-react-native';
import { Colors } from '@/constants/theme';
import { AttachmentsButton } from '@/components/attachments/AttachmentsSheet';
import { useAuth } from '@/context/AuthContext';
import { ForbiddenError, type Session } from '@/security/guard';
import { listCases, listDepartmentOptions, insertCase, DuplicateCaseError, type CaseItem } from '@/services/cases.service';

// يطابق هذا الواجهة تماماً أعمدة جدول cases كما في db.ts الحالي

interface DepartmentItem {
  id: string;
  name: string;
}


export default function CasesScreen() {
  const { user } = useAuth();
  const session = React.useMemo<Session | null>(
    () => (user ? { userId: user.id, role: user.role } : null),
    [user?.id, user?.role]
  );
  const deniedAlerted = useRef(false);
  const [cases, setCases] = useState<CaseItem[]>([]);
  const [departments, setDepartments] = useState<DepartmentItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [deptPickerVisible, setDeptPickerVisible] = useState(false);

  // حقول نموذج الإضافة
  const [caseNumber, setCaseNumber] = useState('');
  const [title, setTitle] = useState('');
  const [caseType, setCaseType] = useState('');
  const [complainant, setComplainant] = useState('');
  const [suspects, setSuspects] = useState('');
  const [incidentLocation, setIncidentLocation] = useState('');
  const [incidentDetails, setIncidentDetails] = useState('');
  const [selectedDept, setSelectedDept] = useState<DepartmentItem | null>(null);

  // البحث
  const [searchQuery, setSearchQuery] = useState('');
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // خريطة سريعة id -> اسم القسم لعرضها في بطاقة القضية دون استعلام JOIN
  const deptMap = React.useMemo(() => {
    const map: Record<string, string> = {};
    departments.forEach((d) => {
      map[d.id] = d.name;
    });
    return map;
  }, [departments]);

  const loadDepartments = useCallback(async () => {
    if (!session) return;
    try { setDepartments(await listDepartmentOptions(session)); }
    catch (error) {
      setDepartments([]);
      if (!(error instanceof ForbiddenError)) console.error('[cases] loadDepts error:', error);
    }
  }, [session]);

  const loadCases = useCallback(async (query: string = '') => {
    if (!session) return; // الجلسة لم تُحمَّل بعد: لا استعلام ولا تنبيه
    try {
      setCases(await listCases(session, query));
    } catch (error) {
      setCases([]);
      if (error instanceof ForbiddenError) {
        if (!deniedAlerted.current) {
          deniedAlerted.current = true;
          Alert.alert('تنبيه', 'ليست لديك صلاحية');
        }
      } else {
        console.error('[cases] loadCases error:', error);
        Alert.alert('خطأ', 'حدث خطأ أثناء تحميل القضايا');
      }
    } finally { setLoading(false); }
  }, [session]);

  // تحميل أولي
  useEffect(() => {
    loadDepartments();
    loadCases();
  }, [loadDepartments, loadCases]);

  // إعادة البحث مع تأخير بسيط (debounce) لتفادي استعلام قاعدة بيانات
  // عند كل ضغطة حرف
  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      loadCases(searchQuery);
    }, 300);
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [searchQuery, loadCases]);

  const resetForm = () => {
    setCaseNumber('');
    setTitle('');
    setCaseType('');
    setComplainant('');
    setSuspects('');
    setIncidentLocation('');
    setIncidentDetails('');
    setSelectedDept(null);
  };

  const handleSaveCase = async () => {
    const trimmedNumber = caseNumber.trim();
    const trimmedTitle = title.trim();
    const trimmedType = caseType.trim();
    if (!trimmedNumber || !trimmedTitle || !trimmedType) {
      Alert.alert('تنبيه', 'يرجى إدخال رقم القضية وعنوانها ونوع القضية'); return;
    }
    setSaving(true);
    try {
      await insertCase(session, {
        caseNumber: trimmedNumber,
        title: trimmedTitle,
        caseType: trimmedType,
        complainant,
        suspects,
        incidentLocation,
        incidentDetails,
        departmentId: selectedDept?.id ?? null,
      });
      setModalVisible(false); resetForm(); await loadCases(searchQuery);
    } catch (error) {
      if (error instanceof ForbiddenError) {
        Alert.alert('تنبيه', 'ليست لديك صلاحية');
      } else if (error instanceof DuplicateCaseError) {
        Alert.alert('خطأ', `رقم القضية "${trimmedNumber}" مستخدم مسبقاً`);
      } else {
        console.error('[cases] save error:', error);
        Alert.alert('خطأ', 'فشل حفظ القضية');
      }
    } finally { setSaving(false); }
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>سجل القضايا</Text>
        <Pressable
          style={styles.addBtn}
          onPress={() => setModalVisible(true)}
          accessibilityLabel="إضافة قضية جديدة"
        >
          <Plus color="#fff" size={24} />
        </Pressable>
      </View>

      {/* شريط البحث */}
      <View style={styles.searchBar}>
        <Search color={Colors.textMuted} size={18} />
        <TextInput
          style={styles.searchInput}
          placeholder="ابحث برقم القضية أو العنوان..."
          placeholderTextColor={Colors.textMuted}
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
        {searchQuery.length > 0 && (
          <Pressable onPress={() => setSearchQuery('')} accessibilityLabel="مسح البحث">
            <X color={Colors.textMuted} size={18} />
          </Pressable>
        )}
      </View>

      {loading ? (
        <ActivityIndicator size="large" color={Colors.primary} style={{ marginTop: 50 }} />
      ) : (
        <FlatList
          data={cases}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ padding: 16, flexGrow: 1 }}
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <FolderOpen color={Colors.textMuted} size={48} />
              <Text style={styles.emptyText}>
                {searchQuery ? 'لا توجد نتائج مطابقة للبحث' : 'لا توجد قضايا مسجلة حالياً'}
              </Text>
            </View>
          }
          renderItem={({ item }) => (
            <View style={styles.caseCard}>
              <View style={styles.caseHeader}>
                <Text style={styles.caseNumber}>{item.case_number}</Text>
                <View style={styles.statusBadge}>
                  <Text style={styles.statusText}>{item.status}</Text>
                </View>
              </View>
              <Text style={styles.caseTitle}>{item.title}</Text>
              <View style={styles.caseMetaRow}>
                <Text style={styles.caseType}>{item.case_type}</Text>
                <Text style={styles.caseDept}>
                  {item.department_id ? (deptMap[item.department_id] ?? '—') : 'بدون قسم'}
                </Text>
              </View>
              {!!item.incident_details && (
                <Text style={styles.caseDetails} numberOfLines={2}>
                  {item.incident_details}
                </Text>
              )}
              <AttachmentsButton entityType="case" entityId={item.id} title={`مرفقات القضية ${item.case_number}`} />
            </View>
          )}
        />
      )}

      {/* نافذة إضافة قضية */}
      <Modal visible={modalVisible} animationType="slide" transparent>
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          style={styles.modalOverlay}
        >
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>تسجيل قضية جديدة</Text>
              <Pressable
                onPress={() => {
                  setModalVisible(false);
                  resetForm();
                }}
                accessibilityLabel="إغلاق"
              >
                <X color={Colors.textPrimary} size={24} />
              </Pressable>
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>
              <TextInput
                style={styles.input}
                placeholder="رقم القضية *"
                placeholderTextColor={Colors.textMuted}
                value={caseNumber}
                onChangeText={setCaseNumber}
                editable={!saving}
              />
              <TextInput
                style={styles.input}
                placeholder="عنوان القضية *"
                placeholderTextColor={Colors.textMuted}
                value={title}
                onChangeText={setTitle}
                editable={!saving}
              />
              <TextInput
                style={styles.input}
                placeholder="نوع القضية (مثال: سرقة، اعتداء) *"
                placeholderTextColor={Colors.textMuted}
                value={caseType}
                onChangeText={setCaseType}
                editable={!saving}
              />

              {/* زر اختيار القسم — يفتح قائمة منسدلة مخصصة (بدون مكتبات خارجية) */}
              <Pressable
                style={styles.deptSelector}
                onPress={() => setDeptPickerVisible(true)}
                disabled={saving}
              >
                <Text
                  style={[
                    styles.deptSelectorText,
                    !selectedDept && { color: Colors.textMuted },
                  ]}
                >
                  {selectedDept ? selectedDept.name : 'اختر القسم (اختياري)'}
                </Text>
                <ChevronDown color={Colors.textMuted} size={18} />
              </Pressable>

              <TextInput
                style={styles.input}
                placeholder="المُبلغ / المجني عليه"
                placeholderTextColor={Colors.textMuted}
                value={complainant}
                onChangeText={setComplainant}
                editable={!saving}
              />
              <TextInput
                style={styles.input}
                placeholder="المشتبه بهم"
                placeholderTextColor={Colors.textMuted}
                value={suspects}
                onChangeText={setSuspects}
                editable={!saving}
              />
              <TextInput
                style={styles.input}
                placeholder="موقع الحادث"
                placeholderTextColor={Colors.textMuted}
                value={incidentLocation}
                onChangeText={setIncidentLocation}
                editable={!saving}
              />
              <TextInput
                style={[styles.input, { height: 100, textAlignVertical: 'top' }]}
                placeholder="تفاصيل الواقعة"
                placeholderTextColor={Colors.textMuted}
                multiline
                value={incidentDetails}
                onChangeText={setIncidentDetails}
                editable={!saving}
              />

              <Pressable
                style={[styles.saveBtn, saving && { opacity: 0.6 }]}
                onPress={handleSaveCase}
                disabled={saving}
              >
                {saving ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.saveBtnText}>حفظ القضية</Text>
                )}
              </Pressable>
            </ScrollView>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* نافذة اختيار القسم (مودال فوق مودال) */}
      <Modal visible={deptPickerVisible} animationType="fade" transparent>
        <Pressable
          style={styles.deptPickerOverlay}
          onPress={() => setDeptPickerVisible(false)}
        >
          <View style={styles.deptPickerContent}>
            <Text style={styles.deptPickerTitle}>اختر القسم</Text>
            <ScrollView style={{ maxHeight: 320 }}>
              <Pressable
                style={styles.deptOption}
                onPress={() => {
                  setSelectedDept(null);
                  setDeptPickerVisible(false);
                }}
              >
                <Text style={styles.deptOptionText}>بدون قسم</Text>
                {!selectedDept && <Check color={Colors.primary} size={18} />}
              </Pressable>
              {departments.map((dept) => (
                <Pressable
                  key={dept.id}
                  style={styles.deptOption}
                  onPress={() => {
                    setSelectedDept(dept);
                    setDeptPickerVisible(false);
                  }}
                >
                  <Text style={styles.deptOptionText}>{dept.name}</Text>
                  {selectedDept?.id === dept.id && (
                    <Check color={Colors.primary} size={18} />
                  )}
                </Pressable>
              ))}
            </ScrollView>
          </View>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  headerTitle: { color: Colors.textPrimary, fontSize: 20, fontFamily: 'Cairo_700Bold' },
  addBtn: {
    backgroundColor: Colors.primary,
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  searchBar: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: Colors.card,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 10,
    marginHorizontal: 16,
    marginTop: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
    gap: 8,
  },
  searchInput: {
    flex: 1,
    color: Colors.textPrimary,
    fontFamily: 'Cairo_400Regular',
    textAlign: 'right',
    fontSize: 14,
  },
  emptyState: { alignItems: 'center', marginTop: 80 },
  emptyText: { color: Colors.textMuted, fontFamily: 'Cairo_400Regular', marginTop: 10 },
  caseCard: {
    backgroundColor: Colors.card,
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  caseHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  caseNumber: { color: Colors.primary, fontFamily: 'Cairo_700Bold', fontSize: 16 },
  statusBadge: {
    backgroundColor: 'rgba(37, 99, 235, 0.2)',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 8,
  },
  statusText: { color: Colors.primary, fontFamily: 'Cairo_600SemiBold', fontSize: 12 },
  caseTitle: { color: Colors.textPrimary, fontFamily: 'Cairo_600SemiBold', fontSize: 16 },
  caseMetaRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 4,
  },
  caseType: {
    color: Colors.textMuted,
    fontFamily: 'Cairo_400Regular',
    fontSize: 12,
  },
  caseDept: {
    color: Colors.textMuted,
    fontFamily: 'Cairo_400Regular',
    fontSize: 12,
  },
  caseDetails: {
    color: Colors.textMuted,
    fontFamily: 'Cairo_400Regular',
    fontSize: 13,
    marginTop: 6,
    textAlign: 'right',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: Colors.card,
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: Colors.border,
    maxHeight: '85%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: { color: Colors.textPrimary, fontSize: 18, fontFamily: 'Cairo_700Bold' },
  input: {
    backgroundColor: Colors.background,
    color: Colors.textPrimary,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
    fontFamily: 'Cairo_400Regular',
    textAlign: 'right',
  },
  deptSelector: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: Colors.background,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
  },
  deptSelectorText: {
    color: Colors.textPrimary,
    fontFamily: 'Cairo_400Regular',
    fontSize: 14,
  },
  saveBtn: {
    backgroundColor: Colors.primary,
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 8,
  },
  saveBtnText: { color: '#fff', fontFamily: 'Cairo_700Bold', fontSize: 16 },
  deptPickerOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'center',
    padding: 30,
  },
  deptPickerContent: {
    backgroundColor: Colors.card,
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  deptPickerTitle: {
    color: Colors.textPrimary,
    fontFamily: 'Cairo_700Bold',
    fontSize: 16,
    textAlign: 'right',
    marginBottom: 12,
  },
  deptOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  deptOptionText: {
    color: Colors.textPrimary,
    fontFamily: 'Cairo_400Regular',
    fontSize: 14,
  },
});
