// SECURECASEDESK_PHASE9_S3
// شاشة التقارير والمستندات (عربية RTL). الصلاحيات هنا للعرض؛ الإنفاذ الفعلي في reports.service/reports-data.
import React, { useCallback, useMemo, useRef, useState } from 'react';
import { View, Text, ScrollView, StyleSheet, Pressable, TextInput, ActivityIndicator, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { ArrowRight, FileText, FileType2, Trash2, Printer, Share2 } from 'lucide-react-native';
import { useAuth } from '@/context/AuthContext';
import { Colors } from '@/constants/theme';
import type { Session } from '@/security/guard';
import { ForbiddenError } from '@/security/guard';
import { listCases, type CaseItem } from '@/services/cases.service';
import {
  generateReport, listAvailableReports, deleteGeneratedReport,
  ReportError, REPORT_ERROR_MESSAGES, type GeneratedReport, type ReportDefinition, type ReportFormat,
} from '@/services/reports.service';
import { fmtDateTime, fmtSize, parseDateInput } from '@/modules/reports/reports-format';
import { shareReportFile, printReport, ExportError, EXPORT_ERROR_MESSAGES } from '@/services/reports-export.service'; // SECURECASEDESK_PHASE9_S4
import type { ReportFilters } from '@/modules/reports/reports-types';

export default function ReportsScreen() {
  const { user } = useAuth();
  const session = useMemo<Session | null>(() => (user ? { userId: user.id, role: user.role } : null), [user?.id, user?.role]);
  const available = useMemo(() => listAvailableReports(session), [session]);

  const [selected, setSelected] = useState<ReportDefinition | null>(null);
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [threshold, setThreshold] = useState('30');
  const [caseQuery, setCaseQuery] = useState('');
  const [cases, setCases] = useState<CaseItem[]>([]);
  const [caseId, setCaseId] = useState<string | null>(null);
  const [busy, setBusy] = useState<ReportFormat | null>(null);
  const [results, setResults] = useState<GeneratedReport[]>([]);
  const busyRef = useRef(false);
  const metaRef = useRef(new Map<string, { kind: string; filters: ReportFilters }>());
  const [acting, setActing] = useState<string | null>(null);

  const searchCases = useCallback(async (q: string) => {
    setCaseQuery(q);
    if (!session) return;
    try { setCases((await listCases(session, q)).slice(0, 20)); } catch { setCases([]); }
  }, [session]);

  const pick = (d: ReportDefinition) => {
    setSelected(d); setCaseId(null); setFrom(''); setTo('');
    if (d.needsCase) void searchCases('');
  };

  const run = async (format: ReportFormat) => {
    if (!session || !selected || busyRef.current) return;
    const dFrom = parseDateInput(from), dTo = parseDateInput(to);
    if (dFrom === null || dTo === null) { Alert.alert('تاريخ غير صالح', 'اكتب التاريخ بالصيغة 2026-11-20 أو اتركه فارغاً.'); return; }
    if (selected.needsCase && !caseId) { Alert.alert('اختر قضية', REPORT_ERROR_MESSAGES.CASE_REQUIRED); return; }
    const th = parseInt(threshold, 10);
    busyRef.current = true; setBusy(format);
    try {
      const r = await generateReport(session, selected.kind, format, {
        caseId: caseId ?? undefined, dateFrom: dFrom, dateTo: dTo, thresholdDays: Number.isFinite(th) ? th : undefined,
      });
      metaRef.current.set(r.uri, { kind: selected.kind, filters: { caseId: caseId ?? undefined, dateFrom: dFrom, dateTo: dTo, thresholdDays: Number.isFinite(th) ? th : undefined } });
      setResults((p) => [r, ...p]);
      Alert.alert('تم إنشاء التقرير', r.title + '\n' + fmtSize(r.sizeBytes) + ' — ' + r.rowCount + ' سجل');
    } catch (e) {
      if (e instanceof ForbiddenError) Alert.alert('غير مصرح', 'ليست لديك صلاحية على هذا التقرير.');
      else if (e instanceof ReportError) Alert.alert('تعذر إنشاء التقرير', REPORT_ERROR_MESSAGES[e.code]);
      else { console.error('[Reports]', e); Alert.alert('تعذر إنشاء التقرير', 'حدث خطأ غير متوقع. لم يُحفظ أي ملف ناقص.'); }
    } finally { busyRef.current = false; setBusy(null); }
  };

  const fail = (e: unknown) => {
    if (e instanceof ForbiddenError) Alert.alert('غير مصرح', 'ليست لديك صلاحية على هذا التقرير.');
    else if (e instanceof ReportError) Alert.alert('تعذر التنفيذ', REPORT_ERROR_MESSAGES[e.code]);
    else if (e instanceof ExportError) Alert.alert('تعذر التصدير', EXPORT_ERROR_MESSAGES[e.code]);
    else { console.error('[ReportsExport]', e); Alert.alert('تعذر التنفيذ', 'حدث خطأ غير متوقع.'); }
  };

  const share = async (r: GeneratedReport) => {
    const m = metaRef.current.get(r.uri);
    if (!session || !m || acting) return;
    setActing(r.uri + ':share');
    try { await shareReportFile(session, r, m.kind); } catch (e) { fail(e); } finally { setActing(null); }
  };

  const printIt = async (r: GeneratedReport) => {
    const m = metaRef.current.get(r.uri);
    if (!session || !m || acting) return;
    setActing(r.uri + ':print');
    try { await printReport(session, m.kind, m.filters); } catch (e) { fail(e); } finally { setActing(null); }
  };

  const remove = (r: GeneratedReport) => {
    Alert.alert('حذف الملف', 'سيُحذف ملف التقرير المؤقت من الجهاز. البيانات الأصلية لا تتأثر.', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'حذف', style: 'destructive', onPress: () => { try { deleteGeneratedReport(r.uri); setResults((p) => p.filter((x) => x.uri !== r.uri)); } catch { Alert.alert('خطأ', 'تعذر حذف الملف.'); } } },
    ]);
  };

  return (
    <SafeAreaView style={s.safe} edges={['top']}>
      <ScrollView contentContainerStyle={s.scroll} keyboardShouldPersistTaps="handled">
        <View style={s.top}>
          <Pressable onPress={() => router.back()} style={s.back} accessibilityLabel="رجوع"><ArrowRight color={Colors.textPrimary} size={20} /></Pressable>
          <Text style={s.title}>التقارير والمستندات</Text>
        </View>

        {available.length === 0 && <Text style={s.muted}>لا توجد تقارير متاحة لصلاحياتك.</Text>}

        {available.map((d) => {
          const on = selected?.kind === d.kind;
          return (
            <Pressable key={d.kind} onPress={() => pick(d)} style={[s.card, on && { borderColor: Colors.primary }]}>
              <Text style={s.cardTitle}>{d.title}</Text>
              <Text style={s.cardDesc}>{d.description}</Text>
            </Pressable>
          );
        })}

        {selected && (
          <View style={s.panel}>
            <Text style={s.panelTitle}>{selected.title}</Text>

            {selected.needsCase && (
              <View>
                <Text style={s.label}>القضية</Text>
                <TextInput style={s.input} value={caseQuery} onChangeText={searchCases} placeholder="ابحث برقم القضية أو عنوانها" placeholderTextColor={Colors.textMuted} textAlign="right" />
                {cases.map((c) => (
                  <Pressable key={c.id} onPress={() => setCaseId(c.id)} style={[s.row, caseId === c.id && { borderColor: Colors.success }]}>
                    <Text style={s.rowText}>{c.case_number} — {c.title}</Text>
                  </Pressable>
                ))}
              </View>
            )}

            {selected.supportsDates && (
              <View>
                <Text style={s.label}>من تاريخ (اختياري)</Text>
                <TextInput style={s.input} value={from} onChangeText={setFrom} placeholder="2026-01-01" placeholderTextColor={Colors.textMuted} keyboardType="numbers-and-punctuation" textAlign="right" />
                <Text style={s.label}>إلى تاريخ (اختياري)</Text>
                <TextInput style={s.input} value={to} onChangeText={setTo} placeholder="2026-12-31" placeholderTextColor={Colors.textMuted} keyboardType="numbers-and-punctuation" textAlign="right" />
              </View>
            )}

            {selected.kind === 'detainees_stats' && (
              <View>
                <Text style={s.label}>حد مدة الاحتجاز بالأيام</Text>
                <TextInput style={s.input} value={threshold} onChangeText={setThreshold} keyboardType="number-pad" textAlign="right" />
              </View>
            )}

            <View style={s.btns}>
              <Pressable disabled={!!busy} onPress={() => run('pdf')} style={[s.btn, { backgroundColor: Colors.primary }, !!busy && { opacity: 0.6 }]}>
                {busy === 'pdf' ? <ActivityIndicator color="#fff" /> : <FileText color="#fff" size={18} />}
                <Text style={s.btnText}>إنشاء PDF</Text>
              </Pressable>
              <Pressable disabled={!!busy} onPress={() => run('docx')} style={[s.btn, { backgroundColor: Colors.secondary, borderWidth: 1, borderColor: Colors.border }, !!busy && { opacity: 0.6 }]}>
                {busy === 'docx' ? <ActivityIndicator color="#fff" /> : <FileType2 color={Colors.secondaryAccent} size={18} />}
                <Text style={[s.btnText, { color: Colors.textPrimary }]}>إنشاء Word</Text>
              </Pressable>
            </View>
          </View>
        )}

        {results.length > 0 && <Text style={s.section}>الملفات المنشأة في هذه الجلسة</Text>}
        {results.map((r) => (
          <View key={r.uri} style={s.card}>
            <Text style={s.cardTitle}>{r.title} — {r.format === 'pdf' ? 'PDF' : 'DOCX'}</Text>
            <Text style={s.cardDesc}>{fmtDateTime(r.createdAt)} — {fmtSize(r.sizeBytes)} — {r.rowCount} سجل</Text>
            <Text style={s.cardDesc}>رقم المستند: {r.documentNumber}</Text>
            <Text style={s.cardDesc}>SHA-256: {r.sha256.slice(0, 16)}…</Text>
            <View style={s.actions}>
              <Pressable disabled={!!acting} onPress={() => share(r)} style={[s.act, !!acting && { opacity: 0.6 }]}>
                {acting === r.uri + ':share' ? <ActivityIndicator color={Colors.secondaryAccent} /> : <Share2 color={Colors.secondaryAccent} size={16} />}
                <Text style={s.actText}>مشاركة</Text>
              </Pressable>
              <Pressable disabled={!!acting} onPress={() => printIt(r)} style={[s.act, !!acting && { opacity: 0.6 }]}>
                {acting === r.uri + ':print' ? <ActivityIndicator color={Colors.secondaryAccent} /> : <Printer color={Colors.secondaryAccent} size={16} />}
                <Text style={s.actText}>طباعة</Text>
              </Pressable>
            </View>
            <Pressable onPress={() => remove(r)} style={s.del}><Trash2 color={Colors.danger} size={16} /><Text style={s.delText}>حذف الملف</Text></Pressable>
          </View>
        ))}
        {results.length > 0 && <Text style={s.muted}>الملفات مؤقتة وتُحذف تلقائياً بعد 24 ساعة. الطباعة تعيد بناء التقرير من البيانات الحالية.</Text>}
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  scroll: { paddingHorizontal: 20, paddingBottom: 48, paddingTop: 12, gap: 10 },
  top: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 8 },
  back: { width: 40, height: 40, borderRadius: 12, backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border, alignItems: 'center', justifyContent: 'center' },
  title: { color: Colors.textPrimary, fontFamily: 'Cairo_700Bold', fontSize: 22, textAlign: 'right', flex: 1 },
  card: { backgroundColor: Colors.card, borderRadius: 16, borderWidth: 1, borderColor: Colors.border, padding: 14, gap: 4 },
  cardTitle: { color: Colors.textPrimary, fontFamily: 'Cairo_700Bold', fontSize: 15, textAlign: 'right' },
  cardDesc: { color: Colors.textSecondary, fontFamily: 'Cairo_400Regular', fontSize: 12, textAlign: 'right' },
  panel: { backgroundColor: Colors.card, borderRadius: 16, borderWidth: 1, borderColor: Colors.primary, padding: 16, gap: 8 },
  panelTitle: { color: Colors.secondaryAccent, fontFamily: 'Cairo_700Bold', fontSize: 16, textAlign: 'right' },
  label: { color: Colors.textSecondary, fontFamily: 'Cairo_600SemiBold', fontSize: 13, textAlign: 'right', marginTop: 6, marginBottom: 4 },
  input: { backgroundColor: Colors.background, borderWidth: 1, borderColor: Colors.border, borderRadius: 12, color: Colors.textPrimary, fontFamily: 'Cairo_400Regular', paddingHorizontal: 12, height: 46 },
  row: { backgroundColor: Colors.background, borderWidth: 1, borderColor: Colors.border, borderRadius: 10, padding: 10, marginTop: 6 },
  rowText: { color: Colors.textPrimary, fontFamily: 'Cairo_400Regular', fontSize: 13, textAlign: 'right' },
  btns: { flexDirection: 'row', gap: 10, marginTop: 12 },
  btn: { flex: 1, height: 48, borderRadius: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  btnText: { color: '#fff', fontFamily: 'Cairo_700Bold', fontSize: 15 },
  section: { color: Colors.textPrimary, fontFamily: 'Cairo_700Bold', fontSize: 16, textAlign: 'right', marginTop: 12 },
  muted: { color: Colors.textMuted, fontFamily: 'Cairo_400Regular', fontSize: 12, textAlign: 'right' },
  actions: { flexDirection: 'row', gap: 10, marginTop: 10 },
  act: { flex: 1, height: 42, borderRadius: 10, borderWidth: 1, borderColor: Colors.border, backgroundColor: Colors.secondary, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6 },
  actText: { color: Colors.textPrimary, fontFamily: 'Cairo_600SemiBold', fontSize: 13 },
  del: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 8, alignSelf: 'flex-start' },
  delText: { color: Colors.danger, fontFamily: 'Cairo_600SemiBold', fontSize: 13 },
});

// SECURECASEDESK_PHASE9_S4
