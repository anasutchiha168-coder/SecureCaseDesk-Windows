// SECURECASEDESK_PHASE9_S2
// نافذة سفلية تحمل لوحة المرفقات، وزر "المرفقات" الذي يفتحها ويعرض العدد.

import React, { useEffect, useMemo, useState } from 'react';
import { View, Text, Pressable, Modal, ScrollView, StyleSheet, I18nManager } from 'react-native';
import { Paperclip, X } from 'lucide-react-native';
import { Colors, Spacing, Radius, Fonts, FontSizes } from '@/constants/theme';
import { useAuth } from '@/context/AuthContext';
import { getAttachmentCount, type AttachmentEntityType } from '@/services/attachments.service';
import { attachmentUiPermissions, toArabicDigits } from '@/modules/attachments/attachments-ui-logic';
import AttachmentsPanel from './AttachmentsPanel';

const ROW: 'row' | 'row-reverse' = I18nManager.isRTL ? 'row' : 'row-reverse';

export function AttachmentsSheet(props: {
  visible: boolean; onClose: () => void; entityType: AttachmentEntityType; entityId: string; title: string;
}) {
  return (
    <Modal visible={props.visible} transparent animationType="slide" statusBarTranslucent onRequestClose={props.onClose}>
      <View style={styles.overlay}>
        <View style={styles.sheet}>
          <View style={styles.sheetHeader}>
            <Text style={styles.sheetTitle} numberOfLines={1}>{props.title}</Text>
            <Pressable onPress={props.onClose} accessibilityLabel="إغلاق"><X size={22} color={Colors.textSecondary} /></Pressable>
          </View>
          <ScrollView contentContainerStyle={{ padding: Spacing.lg }}>
            {props.visible && <AttachmentsPanel entityType={props.entityType} entityId={props.entityId} />}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

// زر مضغوط للبطاقات: لا يظهر أصلاً لمن لا يملك صلاحية عرض مرفقات هذا النوع.
export function AttachmentsButton(props: { entityType: AttachmentEntityType; entityId: string; title: string }) {
  const { user } = useAuth();
  const session = useMemo(() => (user ? { userId: user.id, role: user.role } : null), [user?.id, user?.role]);
  const canView = attachmentUiPermissions(user?.role, props.entityType).canView;
  const [open, setOpen] = useState(false);
  const [count, setCount] = useState<number | null>(null);

  useEffect(() => {
    if (!canView || open) return;
    let alive = true;
    getAttachmentCount(session, props.entityType, props.entityId)
      .then((c) => { if (alive) setCount(c); })
      .catch(() => { if (alive) setCount(null); });
    return () => { alive = false; };
  }, [canView, open, session, props.entityType, props.entityId]);

  if (!canView) return null;
  return (
    <>
      <Pressable style={styles.btn} onPress={() => setOpen(true)} accessibilityLabel="المرفقات">
        <Paperclip size={14} color={Colors.secondaryAccent} />
        <Text style={styles.btnText}>المرفقات{count !== null ? ` (${toArabicDigits(count)})` : ''}</Text>
      </Pressable>
      <AttachmentsSheet visible={open} onClose={() => setOpen(false)}
        entityType={props.entityType} entityId={props.entityId} title={props.title} />
    </>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: Colors.overlay, justifyContent: 'flex-end' },
  sheet: { height: '85%', backgroundColor: Colors.background, borderTopLeftRadius: Radius.xl, borderTopRightRadius: Radius.xl, borderWidth: 1, borderColor: Colors.border },
  sheetHeader: { flexDirection: ROW, justifyContent: 'space-between', alignItems: 'center', padding: Spacing.lg, borderBottomWidth: 1, borderBottomColor: Colors.border },
  sheetTitle: { flex: 1, color: Colors.textPrimary, fontFamily: Fonts.bold, fontSize: FontSizes.lg, textAlign: 'right' },
  btn: { flexDirection: ROW, alignItems: 'center', gap: 6, alignSelf: 'flex-start', marginTop: Spacing.sm, paddingHorizontal: 10, paddingVertical: 6, borderRadius: Radius.sm, backgroundColor: Colors.secondary, borderWidth: 1, borderColor: Colors.border },
  btnText: { color: Colors.secondaryAccent, fontFamily: Fonts.medium, fontSize: FontSizes.sm },
});
