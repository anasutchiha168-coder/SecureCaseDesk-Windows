// SECURECASEDESK_PHASE9_S2
// لوحة المرفقات (عربية RTL): عرض، إضافة، معاينة، فحص سلامة، حذف مصرّح (للمدير فقط مع سبب).
// الواجهة تُخفي الأزرار حسب الدور، لكن الإنفاذ الفعلي في خدمة المرفقات وطبقة البيانات.

import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  View, Text, StyleSheet, Pressable, Modal, TextInput, ActivityIndicator, Image, Alert, I18nManager,
} from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import * as Sharing from 'expo-sharing';
import { File } from 'expo-file-system';
import { FileText, Image as ImageIcon, Plus, ShieldCheck, Trash2, X, Eye } from 'lucide-react-native';
import { Colors, Spacing, Radius, Fonts, FontSizes } from '@/constants/theme';
import { useAuth } from '@/context/AuthContext';
import type { Session } from '@/security/guard';
import {
  addAttachmentFromUri, getAttachments, removeAttachment, checkAttachment,
  openAttachmentToCache, purgeDecryptedCache,
  type AttachmentInfo, type AttachmentEntityType,
} from '@/services/attachments.service';
import {
  attachmentUiPermissions, formatFileSize, fileTypeLabel, isImageMime, precheckPickedFile,
  validateDeleteReason, friendlyAttachmentError, integrityMessage, toArabicDigits, ENTITY_LABELS,
} from '@/modules/attachments/attachments-ui-logic';

const ROW: 'row' | 'row-reverse' = I18nManager.isRTL ? 'row' : 'row-reverse';

function formatDate(ts: number): string {
  const d = new Date(ts);
  return toArabicDigits(`${d.getFullYear()}/${String(d.getMonth() + 1).padStart(2, '0')}/${String(d.getDate()).padStart(2, '0')}`);
}

interface Props {
  entityType: AttachmentEntityType;
  entityId: string;
  onCountChange?: (count: number) => void;
}

export default function AttachmentsPanel({ entityType, entityId, onCountChange }: Props) {
  const { user } = useAuth();
  const session = useMemo<Session | null>(
    () => (user ? { userId: user.id, role: user.role } : null),
    [user?.id, user?.role]
  );
  const perms = useMemo(() => attachmentUiPermissions(user?.role, entityType), [user?.role, entityType]);

  const [items, setItems] = useState<AttachmentInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null); // 'add' أو معرّف المرفق قيد المعالجة
  const [message, setMessage] = useState<{ text: string; ok: boolean } | null>(null);
  const [imageUri, setImageUri] = useState<string | null>(null);
  const [imageName, setImageName] = useState('');
  const [deleteTarget, setDeleteTarget] = useState<AttachmentInfo | null>(null);
  const [reason, setReason] = useState('');
  const [reasonError, setReasonError] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!perms.canView) { setItems([]); setLoading(false); return; }
    try {
      const list = await getAttachments(session, entityType, entityId);
      setItems(list);
      onCountChange?.(list.length);
    } catch (e) {
      setMessage({ text: friendlyAttachmentError(e), ok: false });
    } finally {
      setLoading(false);
    }
  }, [session, entityType, entityId, perms.canView, onCountChange]);

  useEffect(() => {
    purgeDecryptedCache(); // تنظيف أي نسخ مفكوكة متبقية من جلسة سابقة
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const handleAdd = async () => {
    if (busy) return;
    setMessage(null);
    let picked: DocumentPicker.DocumentPickerResult;
    try {
      picked = await DocumentPicker.getDocumentAsync({
        type: ['application/pdf', 'image/jpeg', 'image/png'],
        copyToCacheDirectory: true,
        multiple: false,
      });
    } catch {
      setMessage({ text: 'تعذر فتح منتقي الملفات.', ok: false });
      return;
    }
    if (picked.canceled || !picked.assets?.length) return;
    const asset = picked.assets[0];

    const pre = precheckPickedFile({ name: asset.name, size: asset.size ?? null });
    if (pre) {
      deleteCacheCopy(asset.uri);
      setMessage({ text: pre, ok: false });
      return;
    }

    setBusy('add');
    try {
      await addAttachmentFromUri(session, entityType, entityId,
        { uri: asset.uri, name: asset.name, mimeType: asset.mimeType ?? null });
      setMessage({ text: 'تمت إضافة المرفق وتشفيره بنجاح.', ok: true });
      await load();
    } catch (e) {
      setMessage({ text: friendlyAttachmentError(e), ok: false });
    } finally {
      deleteCacheCopy(asset.uri); // لا تبقى نسخة غير مشفرة في الكاش
      setBusy(null);
    }
  };

  const handleOpen = async (a: AttachmentInfo) => {
    if (busy) return;
    setMessage(null);
    setBusy(a.id);
    try {
      const out = await openAttachmentToCache(session, a.id);
      if (isImageMime(out.mimeType)) {
        setImageName(out.name);
        setImageUri(out.uri);
      } else {
        if (!(await Sharing.isAvailableAsync())) {
          purgeDecryptedCache();
          setMessage({ text: 'لا يتوفر تطبيق لعرض ملفات PDF على هذا الجهاز.', ok: false });
        } else {
          await Sharing.shareAsync(out.uri, { mimeType: 'application/pdf', dialogTitle: out.name });
        }
      }
    } catch (e) {
      setMessage({ text: friendlyAttachmentError(e), ok: false });
    } finally {
      setBusy(null);
    }
  };

  const closeImage = () => {
    setImageUri(null);
    purgeDecryptedCache();
  };

  const handleVerify = async (a: AttachmentInfo) => {
    if (busy) return;
    setBusy(a.id);
    try {
      const r = await checkAttachment(session, a.id);
      setMessage({ text: integrityMessage(r.problem), ok: r.ok });
    } catch (e) {
      setMessage({ text: friendlyAttachmentError(e), ok: false });
    } finally {
      setBusy(null);
    }
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    const err = validateDeleteReason(reason);
    if (err) { setReasonError(err); return; }
    setBusy(deleteTarget.id);
    try {
      await removeAttachment(session, deleteTarget.id, reason.trim());
      setDeleteTarget(null); setReason(''); setReasonError(null);
      setMessage({ text: 'تم حذف المرفق وتسجيل العملية في سجل التدقيق.', ok: true });
      await load();
    } catch (e) {
      setReasonError(friendlyAttachmentError(e));
    } finally {
      setBusy(null);
    }
  };

  if (!perms.canView) {
    return (
      <View style={styles.box}>
        <Text style={styles.emptyText}>ليس لديك صلاحية عرض المرفقات.</Text>
      </View>
    );
  }

  return (
    <View style={styles.box}>
      <View style={styles.headerRow}>
        <Text style={styles.title}>المرفقات ({toArabicDigits(items.length)})</Text>
        {perms.canAdd && (
          <Pressable
            style={[styles.addBtn, busy === 'add' && { opacity: 0.6 }]}
            onPress={handleAdd}
            disabled={busy !== null}
            accessibilityLabel={`إضافة مرفق إلى ${ENTITY_LABELS[entityType]}`}
          >
            {busy === 'add'
              ? <ActivityIndicator size="small" color="#fff" />
              : <Plus size={16} color="#fff" />}
            <Text style={styles.addBtnText}>إضافة مرفق</Text>
          </Pressable>
        )}
      </View>

      {message && (
        <View style={[styles.msg, { borderColor: message.ok ? Colors.success : Colors.danger }]}>
          <Text style={[styles.msgText, { color: message.ok ? Colors.success : Colors.danger }]}>{message.text}</Text>
        </View>
      )}

      {loading ? (
        <ActivityIndicator color={Colors.primary} style={{ marginVertical: Spacing.lg }} />
      ) : items.length === 0 ? (
        <Text style={styles.emptyText}>لا توجد مرفقات لهذا السجل.</Text>
      ) : (
        items.map((a) => (
          <View key={a.id} style={styles.item}>
            <View style={styles.itemTop}>
              {isImageMime(a.mime_type)
                ? <ImageIcon size={22} color={Colors.secondaryAccent} />
                : <FileText size={22} color={Colors.warning} />}
              <View style={{ flex: 1 }}>
                <Text style={styles.itemName} numberOfLines={2}>{a.original_name}</Text>
                <Text style={styles.itemMeta}>
                  {fileTypeLabel(a.mime_type)} • {formatFileSize(a.size_bytes)} • {formatDate(a.created_at)}
                </Text>
                {!!a.created_by_name && <Text style={styles.itemMeta}>أضافه: {a.created_by_name}</Text>}
              </View>
              {busy === a.id && <ActivityIndicator size="small" color={Colors.primary} />}
            </View>
            <View style={styles.actions}>
              <Pressable style={styles.actBtn} onPress={() => handleOpen(a)} disabled={busy !== null}>
                <Eye size={16} color={Colors.primary} />
                <Text style={styles.actText}>{isImageMime(a.mime_type) ? 'معاينة' : 'فتح'}</Text>
              </Pressable>
              {perms.canVerify && (
                <Pressable style={styles.actBtn} onPress={() => handleVerify(a)} disabled={busy !== null}>
                  <ShieldCheck size={16} color={Colors.success} />
                  <Text style={styles.actText}>فحص السلامة</Text>
                </Pressable>
              )}
              {perms.canDelete && (
                <Pressable
                  style={styles.actBtn}
                  onPress={() => { setDeleteTarget(a); setReason(''); setReasonError(null); }}
                  disabled={busy !== null}
                >
                  <Trash2 size={16} color={Colors.danger} />
                  <Text style={[styles.actText, { color: Colors.danger }]}>حذف</Text>
                </Pressable>
              )}
            </View>
          </View>
        ))
      )}

      {/* معاينة الصور */}
      <Modal visible={imageUri !== null} transparent animationType="fade" statusBarTranslucent onRequestClose={closeImage}>
        <View style={styles.imgOverlay}>
          <View style={styles.imgTop}>
            <Text style={styles.imgTitle} numberOfLines={1}>{imageName}</Text>
            <Pressable onPress={closeImage} accessibilityLabel="إغلاق المعاينة"><X size={24} color={Colors.textPrimary} /></Pressable>
          </View>
          {imageUri && <Image source={{ uri: imageUri }} style={styles.img} resizeMode="contain" />}
        </View>
      </Modal>

      {/* سبب الحذف */}
      <Modal visible={deleteTarget !== null} transparent animationType="fade" statusBarTranslucent
        onRequestClose={() => setDeleteTarget(null)}>
        <View style={styles.dlgOverlay}>
          <View style={styles.dlg}>
            <Text style={styles.dlgTitle}>حذف المرفق</Text>
            <Text style={styles.dlgText} numberOfLines={2}>{deleteTarget?.original_name}</Text>
            <Text style={styles.dlgHint}>
              يُحذف الملف المشفر ويبقى سجل المرفق (الاسم والبصمة والسبب والمنفّذ) محفوظاً في السجل.
            </Text>
            <TextInput
              style={styles.input}
              placeholder="سبب الحذف (5 أحرف على الأقل)"
              placeholderTextColor={Colors.textMuted}
              value={reason}
              onChangeText={(t) => { setReason(t); setReasonError(null); }}
              textAlign="right"
              multiline
            />
            {!!reasonError && <Text style={styles.errText}>{reasonError}</Text>}
            <View style={styles.dlgActions}>
              <Pressable style={[styles.dlgBtn, { backgroundColor: Colors.secondary }]} onPress={() => setDeleteTarget(null)}>
                <Text style={styles.dlgBtnText}>إلغاء</Text>
              </Pressable>
              <Pressable style={[styles.dlgBtn, { backgroundColor: Colors.danger }]} onPress={confirmDelete} disabled={busy !== null}>
                <Text style={styles.dlgBtnText}>تأكيد الحذف</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

function deleteCacheCopy(uri: string): void {
  try {
    const f = new File(uri);
    if (f.exists) f.delete();
  } catch {
    // فشل تنظيف الكاش لا يؤثر على نتيجة العملية.
  }
}

const styles = StyleSheet.create({
  box: { backgroundColor: Colors.card, borderRadius: Radius.lg, borderWidth: 1, borderColor: Colors.border, padding: Spacing.md, gap: Spacing.sm },
  headerRow: { flexDirection: ROW, justifyContent: 'space-between', alignItems: 'center' },
  title: { color: Colors.textPrimary, fontFamily: Fonts.bold, fontSize: FontSizes.lg, textAlign: 'right' },
  addBtn: { flexDirection: ROW, alignItems: 'center', gap: 6, backgroundColor: Colors.primary, paddingHorizontal: 12, paddingVertical: 8, borderRadius: Radius.md },
  addBtnText: { color: '#fff', fontFamily: Fonts.semiBold, fontSize: FontSizes.sm },
  msg: { borderWidth: 1, borderRadius: Radius.sm, padding: Spacing.sm },
  msgText: { fontFamily: Fonts.medium, fontSize: FontSizes.sm, textAlign: 'right' },
  emptyText: { color: Colors.textMuted, fontFamily: Fonts.regular, fontSize: FontSizes.sm, textAlign: 'center', paddingVertical: Spacing.md },
  item: { backgroundColor: Colors.secondary, borderRadius: Radius.md, padding: Spacing.sm, gap: Spacing.sm, borderWidth: 1, borderColor: Colors.border },
  itemTop: { flexDirection: ROW, alignItems: 'center', gap: Spacing.sm },
  itemName: { color: Colors.textPrimary, fontFamily: Fonts.semiBold, fontSize: FontSizes.md, textAlign: 'right' },
  itemMeta: { color: Colors.textSecondary, fontFamily: Fonts.regular, fontSize: FontSizes.xs, textAlign: 'right' },
  actions: { flexDirection: ROW, gap: Spacing.sm, flexWrap: 'wrap' },
  actBtn: { flexDirection: ROW, alignItems: 'center', gap: 6, paddingHorizontal: 10, paddingVertical: 6, borderRadius: Radius.sm, backgroundColor: Colors.card },
  actText: { color: Colors.textPrimary, fontFamily: Fonts.medium, fontSize: FontSizes.sm },
  imgOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.95)', paddingTop: 40 },
  imgTop: { flexDirection: ROW, justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: Spacing.lg, paddingBottom: Spacing.md },
  imgTitle: { flex: 1, color: Colors.textPrimary, fontFamily: Fonts.semiBold, fontSize: FontSizes.md, textAlign: 'right' },
  img: { flex: 1, width: '100%' },
  dlgOverlay: { flex: 1, backgroundColor: Colors.overlay, justifyContent: 'center', padding: Spacing.xl },
  dlg: { backgroundColor: Colors.card, borderRadius: Radius.lg, padding: Spacing.lg, gap: Spacing.sm, borderWidth: 1, borderColor: Colors.border },
  dlgTitle: { color: Colors.textPrimary, fontFamily: Fonts.bold, fontSize: FontSizes.lg, textAlign: 'right' },
  dlgText: { color: Colors.textSecondary, fontFamily: Fonts.medium, fontSize: FontSizes.sm, textAlign: 'right' },
  dlgHint: { color: Colors.textMuted, fontFamily: Fonts.regular, fontSize: FontSizes.xs, textAlign: 'right' },
  input: { backgroundColor: Colors.secondary, borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.border, color: Colors.textPrimary, fontFamily: Fonts.regular, padding: Spacing.md, minHeight: 70, textAlignVertical: 'top' },
  errText: { color: Colors.danger, fontFamily: Fonts.medium, fontSize: FontSizes.sm, textAlign: 'right' },
  dlgActions: { flexDirection: ROW, gap: Spacing.sm, marginTop: Spacing.sm },
  dlgBtn: { flex: 1, paddingVertical: 12, borderRadius: Radius.md, alignItems: 'center' },
  dlgBtnText: { color: '#fff', fontFamily: Fonts.bold, fontSize: FontSizes.md },
});
